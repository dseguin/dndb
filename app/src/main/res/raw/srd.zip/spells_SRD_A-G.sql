BEGIN TRANSACTION;

INSERT OR IGNORE INTO source (shortname,name) VALUES
    ('SRD','Basic Rules');

INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You hurl a bubble of acid. Choose one or two creatures you can see within range. If you choose two, they must be within 5 feet of each other. A target must succeed on a Dexterity saving throw or take 1d6 acid damage.','This spell''s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6).','Instantaneous','1 action','Acid Splash',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),0,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Your spell bolsters your allies with toughness and resolve. Choose up to three creatures within range. Each target''s hit point maximum and current hit points increase by 5 for the duration.','When you cast this spell using a spell slot of 3rd level or higher, a target''s hit points increase by an additional 5 for each slot level above 2nd.','8 hours','1 action','Aid',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),2,'30 feet','A tiny strip of white cloth',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You set an alarm against unwanted intrusion. Choose a door, a window, or an area within range that is no larger than a 20-foot cube. Until the spell ends, an alarm alerts you whenever a Tiny or larger creature touches or enters the warded area. When you cast the spell, you can designate creatures that won''t set off the alarm. You also choose whether the alarm is mental or audible.

A mental alarm alerts you with a ping in your mind if you are within 1 mile of the warded area. This ping awakens you if you are sleeping.

An audible alarm produces the sound of a hand bell for 10 seconds within 60 feet.',NULL,'8 hours','1 minute','Alarm',1,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),1,'30 feet','A tiny bell and a piece of fine silver wire',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You assume a different form. When you cast the spell, choose one of the following options, the effects of which last for the duration of the spell. While the spell lasts, you can end one option as an action to gain the benefits of a different one.

Aquatic Adaptation. You adapt your body to an aquatic environment, sprouting gills and growing webbing between your fingers. You can breathe underwater and gain a swimming speed equal to your walking speed.

Change Appearance. You transform your appearance. You decide what you look like, including your height, weight, facial features, sound of your voice, hair length, coloration, and distinguishing characteristics, if any. You can make yourself appear as a member of another race, though none of your statistics change. You also can''t appear as a creature of a different size than you, and your basic shape stays the same; if you''re bipedal, you can''t use this spell to become quadrupedal, for instance. At any time for the duration of the spell, you can use your action to change your appearance in this way again.

Natural Weapons. You grow claws, fangs, spines, horns, or a different natural weapon of your choice. Your unarmed strikes deal 1d6 bludgeoning, piercing, or slashing damage, as appropriate to the natural weapon you chose, and you are proficient with your unarmed strikes. Finally, the natural weapon is magic and you have a +1 bonus to the attack and damage rolls you make using it.',NULL,'1 hour','1 action','Alter Self',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'This spell lets you convince a beast that you mean it no harm. Choose a beast that you can see within range. It must see and hear you. If the beast''s Intelligence is 4 or higher, the spell fails. Otherwise, the beast must succeed on a Wisdom saving throw or be charmed by you for the spell''s duration. If you or one of your companions harms the target, the spell ends.','When you cast this spell using a spell slot of 2nd level or higher, you can affect one additional beast for each slot level above 1st.','24 hours','1 action','Animal Friendship',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),1,'30 feet','A morsel of food',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'By means of this spell, you use an animal to deliver a message. Choose a Tiny beast you can see within range, such as a squirrel, a blue jay, or a bat. You specify a location, which you must have visited, and a recipient who matches a general description, such as "a man or woman dressed in the uniform of the town guard" or "a red-haired dwarf wearing a pointed hat." You also speak a message of up to twenty-five words. The target beast travels for the duration of the spell toward the specified location, covering about 50 miles per 24 hours for a flying messenger, or 25 miles for other animals.

When the messenger arrives, it delivers your message to the creature that you described, replicating the sound of your voice. The messenger speaks only to a creature matching the description you gave. If the messenger doesn''t reach its destination before the spell ends, the message is lost, and the beast makes its way back to where you cast this spell.','If you cast this spell using a spell slot of 3nd level or higher, the duration of the spell increases by 48 hours for each slot level above 2nd.','24 hours','1 action','Animal Messenger',1,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),2,'30 feet','A morsel of food',0,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Your magic turns others into beasts. Choose any number of willing creatures that you can see within range. You transform each target into the form of a Large or smaller beast with a challenge rating of 4 or lower. On subsequent turns, you can use your action to transform affected creatures into new forms.

The transformation lasts for the duration for each target, or until the target drops to 0 hit points or dies. You can choose a different form for each target. A target''s game statistics are replaced by the statistics of the chosen beast, though the target retains its alignment and Intelligence, Wisdom, and Charisma scores. The target assumes the hit points of its new form, and when it reverts to its normal form, it returns to the number of hit points it had before it transformed. If it reverts as a result of dropping to 0 hit points, any excess damage carries over to its normal form. As long as the excess damage doesn''t reduce the creature''s normal form to 0 hit points, it isn''t knocked unconscious. The creature is limited in the actions it can perform by the nature of its new form, and it can''t speak or cast spells.

The target''s gear melds into the new form. The target can''t activate, wield, or otherwise benefit from any of its equipment.',NULL,'24 hours','1 action','Animal Shapes',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),8,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'This spell creates an undead servant. Choose a pile of bones or a corpse of a Medium or Small humanoid within range. Your spell imbues the target with a foul mimicry of life, raising it as an undead creature. The target becomes a skeleton if you chose bones or a zombie if you chose a corpse (the DM has the creature''s game statistics).

On each of your turns, you can use a bonus action to mentally command any creature you made with this spell if the creature is within 60 feet of you (if you control multiple creatures, you can command any or all of them at the same time, issuing the same command to each one). You decide what action the creature will take and where it will move during its next turn, or you can issue a general command, such as to guard a particular chamber or corridor. If you issue no commands, the creature only defends itself against hostile creatures. Once given an order, the creature continues to follow it until its task is complete.

The creature is under your control for 24 hours, after which it stops obeying any command you''ve given it. To maintain control of the creature for another 24 hours, you must cast this spell on the creature again before the current 24-hour period ends. This use of the spell reasserts your control over up to four creatures you have animated with this spell, rather than animating a new one.','When you cast this spell using a spell slot of 4th level or higher, you animate or reassert control over two additional undead creatures for each slot level above 3rd. Each of the creatures must come from a different corpse or pile of bones.','Instantaneous','1 minute','Animate Dead',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),3,'10 feet','A drop of blood, a piece of flesh, and a pinch of bone dust',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Objects come to life at your command. Choose up to ten nonmagical objects within range that are not being worn or carried. Medium targets count as two objects, Large targets count as four objects, Huge targets count as eight objects. You can''t animate any object larger than Huge. Each target animates and becomes a creature under your control until the spell ends or until reduced to 0 hit points.

As a bonus action, you can mentally command any creature you made with this spell if the creature is within 500 feet of you (if you control multiple creatures, you can command any or all of them at the same time, issuing the same command to each one). You decide what action the creature will take and where it will move during its next turn, or you can issue a general command, such as to guard a particular chamber or corridor. If you issue no commands, the creature only defends itself against hostile creatures. Once given an order, the creature continues to follow it until its task is complete.

Animated Object Statistics
Size    |HP     |AC     |Str    |Dex    |Attack
Tiny    |20     |18     |4      |18     |+8 to hit, 1d4 + 4 damage
Small   |25     |16     |6      |14     |+6 to hit, 1d8 + 2 damage
Medium  |40     |13     |10     |12     |+5 to hit, 2d6 + 1 damage
Large   |50     |10     |14     |10     |+6 to hit, 2d10 + 2 damage
Huge    |80     |10     |18     |6      |+8 to hit, 2d12 + 4 damage

An animated object is a construct with AC, hit points, attacks, Strength, and Dexterity determined by its size. Its Constitution is 10 and its Intelligence and Wisdom are 3, and its Charisma is 1. Its speed is 30 feet; if the object lacks legs or other appendages it can use for locomotion, it instead has a flying speed of 30 feet and can hover. If the object is securely attached to a surface or a larger object, such as a chain bolted to a wall, its speed is 0. It has blindsight with a radius of 30 feet and is blind beyond that distance. When the animated object drops to 0 hit points, it reverts to its original object form, and any remaining damage carries over to its
original object form. 

If you command an object to attack, it can make a single melee attack against a creature within 5 feet of it. It makes a slam attack with an attack bonus and bludgeoning damage determined by its size. The GM might rule that a specific object inflicts slashing or piercing damage based on its form.','If you cast this spell using a spell slot of 6th level or higher, you can animate two additional objects for each slot level above 5th.','1 minute','1 action','Animate Objects',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),5,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A shimmering barrier extends out from you in a 10-foot radius and moves with you, remaining centered on you and hedging out creatures other than undead and constructs. The barrier lasts for the duration.

The barrier prevents an affected creature from passing or reaching through. An affected creature can cast spells or make attacks with ranged or reach weapons through the barrier.

If you move so that an affected creature is forced to pass through the barrier, the spell ends.',NULL,'1 hour','1 action','Antilife Shell',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),5,'Self (10 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A 10-foot-radius invisible sphere of antimagic surrounds you. This area is divorced from the magical energy that suffuses the multiverse. Within the sphere, spells can''t be cast, summoned creatures disappear, and even magic items become mundane. Until the spell ends, the sphere moves with you, centered on you.

Spells and other magical effects, except those created by an artifact or a deity, are suppressed in the sphere and can''t protrude into it. A slot expended to cast a suppressed spell is consumed. While an effect is suppressed, it doesn''t function, but the time it spends suppressed counts against its duration.

Targeted Effects. Spells and other magical effects, such as magic missile and charm person, that target a creature or an object in the sphere have no effect on that target.

Areas of Magic. The area of another spell or magical effect, such as fireball, can''t extend into the sphere. If the sphere overlaps an area of magic, the part of the area that is covered by the sphere is suppressed. For example, the flames created by a wall of fire are suppressed within the sphere, creating a gap in the wall if the overlap is large enough.

Spells. Any active spell or other magical effect on a creature or an object in the sphere is suppressed while the creature or object is in it.

Magic Items. The properties and powers of magic items are suppressed in the sphere. For example, a longsword, +1 in the sphere functions as a nonmagical longsword.

A magic weapon''s properties and powers are suppressed if it is used against a target in the sphere or wielded by an attacker in the sphere. If a magic weapon or a piece of magic ammunition fully leaves the sphere (for example, if you fire a magic arrow or throw a magic spear at a target outside the sphere), the magic of the item ceases to be suppressed as soon as it exits.

Magical Travel. Teleportation and planar travel fail to work in the sphere, whether the sphere is the destination or the departure point for such magical travel. A portal to another location, world, or plane of existence, as well as an opening to an extradimensional space such as that created by the rope trick spell, temporarily closes while in the sphere.

Creatures and Objects. A creature or object summoned or created by magic temporarily winks out of existence in the sphere. Such a creature instantly reappears once the space the creature occupied is no longer within the sphere.

Dispel Magic. Spells and magical effects such as dispel magic have no effect on the sphere. Likewise, the spheres created by different antimagic field spells don''t nullify each other.',NULL,'1 hour','1 action','Antimagic Field',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),8,'Self (10 feet)','A pinch of powdered iron or iron filings',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'This spell attracts or repels creatures of your choice. You target something within range, either a Huge or smaller object or creature or an area that is no larger than a 200-foot cube. Then specify a kind of intelligent creature, such as red dragons, goblins, or vampires. You invest the target with an aura that either attracts or repels the specified creatures for the duration. Choose antipathy or sympathy as the aura''s effect.

Antipathy. The enchantment causes creatures of the kind you designated to feel an intense urge to leave the area and avoid the target. When such a creature can see the target or comes within 60 feet of it, the creature must succeed on a Wisdom saving throw or become frightened. The creature remains frightened while it can see the target or is within 60 feet of it. While frightened by the target, the creature must use its movement to move to the nearest safe spot from which it can''t see the target. If the creature moves more than 60 feet from the target and can''t see it, the creature is no longer frightened, but the creature becomes frightened again if it regains sight of the target or moves within 60 feet of it.

Sympathy. The enchantment causes the specified creatures to feel an intense urge to approach the target while within 60 feet of it or able to see it. When such a creature can see the target or comes within 60 feet of it, the creature must succeed on a Wisdom saving throw or use its movement on each of its turns to enter the area or move within reach of the target. When the creature has done so, it can''t willingly move away from the target.

If the target damages or otherwise harms an affected creature, the affected creature can make a Wisdom saving throw to end the effect, as described below.

Ending the Effect. If an affected creature ends its turn while not within 60 feet of the target or able to see it, the creature makes a Wisdom saving throw. On a successful save, the creature is no longer affected by the target and recognizes the feeling of repugnance or attraction as magical. In addition, a creature affected by the spell is allowed another Wisdom saving throw every 24 hours while the spell persists.

A creature that successfully saves against this effect is immune to it for 1 minute, after which time it can be affected again.',NULL,'10 days','1 hour','Antipathy/Sympathy',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),8,'60 feet (200 feet)','Either a lump of alum soaked in vinegar for the antipathy effect or a drop of honey for the sympathy effect',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create an invisible, magical eye within range that hovers in the air for the duration.

You mentally receive visual information from the eye, which has normal vision and darkvision out to 30 feet. The eye can look in every direction.

As an action, you can move the eye up to 30 feet in any direction. There is no limit to how far away from you the eye can move, but it can''t enter another plane of existence. A solid barrier blocks the eye''s movement, but the eye can pass through an opening as small as 1 inch in diameter.',NULL,'1 hour','1 action','Arcane Eye',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),4,'30 feet','A bit of bat fur',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a closed door, window, gate, chest, or other entryway, and it becomes locked for the duration. You and the creatures you designate when you cast this spell can open the object normally. You can also set a password that, when spoken within 5 feet of the object, suppresses this spell for 1 minute. Otherwise, it is impassable until it is broken or the spell is dispelled or suppressed. Casting knock on the object suppresses arcane lock for 10 minutes.

While affected by this spell, the object is more difficult to break or force open; the DC to break it or pick any locks on it increases by 10.',NULL,'Until Dispelled','1 action','Arcane Lock',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),2,'Touch','Gold dust worth at least 25 gp, which the spell consumes',25,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You and up to eight willing creatures within range project your astral bodies into the Astral Plane (the spell fails and the casting is wasted if you are already on that plane). The material body you leave behind is unconscious and in a state of suspended animation; it doesn''t need food or air and doesn''t age.

Your astral body resembles your mortal form in almost every way, replicating your game statistics and possessions. The principal difference is the addition of a silvery cord that extends from between your shoulder blades and trails behind you, fading to invisibility after 1 foot. This cord is your tether to your material body. As long as the tether remains intact, you can find your way home. If the cord is cut—something that can happen only when an effect specifically states that it does—your soul and body are separated, killing you instantly.

Your astral form can freely travel through the Astral Plane and can pass through portals there leading to any other plane. If you enter a new plane or return to the plane you were on when casting this spell, your body and possessions are transported along the silver cord, allowing you to re-enter your body as you enter the new plane. Your astral form is a separate incarnation. Any damage or other effects that apply to it have no effect on your physical body, nor do they persist when you return to it.

The spell ends for you and your companions when you use your action to dismiss it. When the spell ends, the affected creature returns to its physical body, and it awakens.

The spell might also end early for you or one of your companions. A successful dispel magic spell used against an astral or physical body ends the spell for that creature. If a creature''s original body or its astral form drops to 0 hit points, the spell ends for that creature. If the spell ends and the silver cord is intact, the cord pulls the creature''s astral form back to its body, ending its state of suspended animation.

If you are returned to your body prematurely, your companions remain in their astral forms and must find their own way back to their bodies, usually by dropping to 0 hit points.',NULL,'Special','1 hour','Astral Projection',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),9,'10 feet','For each creature you affect with this spell, you must provide one jacinth worth at least 1,000 gp and one ornately carved bar of silver worth at least 100 gp, all of which the spell consumes',1100,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'By casting gem-inlaid sticks, rolling dragon bones, laying out ornate cards, or employing some other divining tool, you receive an omen from an otherworldly entity about the results of a specific course of action that you plan to take within the next 30 minutes. The DM chooses from the following possible omens:

- Weal, for good results
- Woe, for bad results
- Weal and woe, for both good and bad results
- Nothing, for results that aren''t especially good or bad

The spell doesn''t take into account any possible circumstances that might change the outcome, such as the casting of additional spells or the loss or gain of a companion.

If you cast the spell two or more times before completing your next long rest, there is a cumulative 25 percent chance for each casting after the first that you get a random reading. The DM makes this roll in secret.',NULL,'Instantaneous','1 minute','Augury',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),2,'Self','Specially marked sticks, bones, or similar tokens worth at least 25 gp',25,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'After spending the casting time tracing magical pathways within a precious gemstone, you touch a Huge or smaller beast or plant. The target must have either no Intelligence score or an Intelligence of 3 or less. The target gains an Intelligence of 10. The target also gains the ability to speak one language you know. If the target is a plant, it gains the ability to move its limbs, roots, vines, creepers, and so forth, and it gains senses similar to a human''s. Your DM chooses statistics appropriate for the awakened plant, such as the statistics for the awakened shrub or the awakened tree.

The awakened beast or plant is charmed by you for 30 days or until you or your companions do anything harmful to it. When the charmed condition ends, the awakened creature chooses whether to remain friendly to you, based on how you treated it while it was charmed.',NULL,'Instantaneous','8 hours','Awaken',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),5,'Touch','An agate worth at least 1,000 gp, which the spell consumes',1000,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Up to three creatures of your choice that you can see within range must make Charisma saving throws. Whenever a target that fails this saving throw makes an attack roll or a saving throw before the spell ends, the target must roll a d4 and subtract the number rolled from the attack roll or saving throw.','When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st.','1 minute','1 action','Bane',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),1,'30 feet','A drop of blood',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You attempt to send one creature that you can see within range to another plane of existence. The target must succeed on a Charisma saving throw or be banished.

If the target is native to the plane of existence you''re on, you banish the target to a harmless demiplane. While there, the target is incapacitated. The target remains there until the spell ends, at which point the target reappears in the space it left or in the nearest unoccupied space if that space is occupied.

If the target is native to a different plane of existence than the one you''re on, the target is banished with a faint popping noise, returning to its home plane. If the spell ends before 1 minute has passed, the target reappears in the space it left or in the nearest unoccupied space if that space is occupied. Otherwise, the target doesn''t return.','When you cast this spell using a spell slot of 5th level or higher, you can target one additional creature for each slot level above 4th.','1 minute','1 action','Banishment',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),4,'60 feet','An item distasteful to the target',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You touch a willing creature. Until the spell ends, the target''s skin has a rough, bark-like appearance, and the target''s AC can''t be less than 16, regardless of what kind of armor it is wearing.',NULL,'1 hour','1 action','Barkskin',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'Touch','A handful of oak bark',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'This spell bestows hope and vitality. Choose any number of creatures within range. For the duration, each target has advantage on Wisdom saving throws and death saving throws, and regains the maximum number of hit points possible from any healing.',NULL,'1 minute','1 action','Beacon of Hope',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),3,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You touch a creature, and that creature must succeed on a Wisdom saving throw or become cursed for the duration of the spell. When you cast this spell, choose the nature of the curse from the following options:

- Choose one ability score. While cursed, the target has disadvantage on ability checks and saving throws made with that ability score.
- While cursed, the target has disadvantage on attack rolls against you.
- While cursed, the target must make a Wisdom saving throw at the start of each of its turns. If it fails, it wastes its action that turn doing nothing.
- While the target is cursed, your attacks and spells deal an extra 1d8 necrotic damage to the target.

A remove curse spell ends this effect. At the DM''s option, you may choose an alternative curse effect, but it should be no more powerful than those described above. The DM has final say on such a curse''s effect.','If you cast this spell using a spell slot of 4th level or higher, the duration is concentration, up to 10 minutes. If you use a spell slot of 5th level or higher, the duration is 8 hours. If you use a spell slot of 7th level or higher, the duration is 24 hours. If you use a 9th level spell slot, the spell lasts until it is dispelled. Using a spell slot of 5th level or higher grants a duration that doesn''t require concentration.','1 minute','1 action','Bestow Curse',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),3,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create a vertical wall of whirling, razor-sharp blades made of magical energy. The wall appears within range and lasts for the duration. You can make a straight wall up to 100 feet long, 20 feet high, and 5 feet thick, or a ringed wall up to 60 feet in diameter, 20 feet high, and 5 feet thick. The wall provides three-quarters cover to creatures behind it, and its space is difficult terrain.

When a creature enters the wall''s area for the first time on a turn or starts its turn there, the creature must make a Dexterity saving throw. On a failed save, the creature takes 6d10 slashing damage. On a successful save, the creature takes half as much damage.',NULL,'10 minutes','1 action','Blade Barrier',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),6,'90 feet',NULL,NULL,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You bless up to three creatures of your choice within range. Whenever a target makes an attack roll or a saving throw before the spell ends, the target can roll a d4 and add the number rolled to the attack roll or saving throw.','When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st.','1 minute','1 action','Bless',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),1,'30 feet','A sprinkling of holy water',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Necromantic energy washes over a creature of your choice that you can see within range, draining moisture and vitality from it. The target must make a Constitution saving throw. The target takes 8d8 necrotic damage on a failed save, or half as much damage on a successful one. This spell has no effect on undead or constructs.

If you target a plant creature or a magical plant, it makes the saving throw with disadvantage, and the spell deals maximum damage to it.

If you target a nonmagical plant that isn''t a creature, such as a tree or shrub, it doesn''t make a saving throw; it simply withers and dies.','When you cast this spell using a spell slot of 5th level or higher, the damage increases by 1d8 for each slot level above 4th.','Instantaneous','1 action','Blight',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),4,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You can blind or deafen a foe. Choose one creature that you can see within range to make a Constitution saving throw. If it fails, the target is either blinded or deafened (your choice) for the duration. At the end of each of its turns, the target can make a Constitution saving throw. On a success, the spell ends.','When you cast this spell using a spell slot of 3rd level or higher, you can target one additional creature for each slot level above 2nd.','1 minute','1 action','Blindness/Deafness',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),2,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Roll a d20 at the end of each of your turns for the duration of the spell. On a roll of 11 or higher, you vanish from your current plane of existence and appear in the Ethereal Plane (the spell fails and the casting is wasted if you were already on that plane). At the start of your next turn, and when the spell ends if you are on the Ethereal Plane, you return to an unoccupied space of your choice that you can see within 10 feet of the space you vanished from. If no unoccupied space is available within that range, you appear in the nearest unoccupied space (chosen at random if more than one space is equally near). You can dismiss this spell as an action.

While on the Ethereal Plane, you can see and hear the plane you originated from, which is cast in shades of gray, and you can''t see anything there more than 60 feet away. You can only affect and be affected by other creatures on the Ethereal Plane. Creatures that aren''t there can''t perceive you or interact with you, unless they have the ability to do so.',NULL,'1 minute','1 action','Blink',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),3,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Your body becomes blurred, shifting and wavering to all who can see you. For the duration, any creature has disadvantage on attack rolls against you. An attacker is immune to this effect if it doesn''t rely on sight, as with blindsight, or can see through illusions, as with truesight.',NULL,'1 minute','1 action','Blur',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),2,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'The next time you hit a creature with a weapon attack before this spell ends, the weapon gleams with astral radiance as you strike. The attack deals an extra 2d6 radiant damage to the target, which becomes visible if it''s invisible, and the target sheds dim light in a 5-foot radius and can''t become invisible until the spell ends.','When you cast this spell using a spell slot of 3rd level or higher, the extra damage increases by 1d6 for each slot level above 2nd.','1 minute','1 bonus action','Branding Smite',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),2,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'As you hold your hands with thumbs touching and fingers spread, a thin sheet of flames shoots forth from your outstretched fingertips. Each creature in a 15-foot cone must make a Dexterity saving throw. A creature takes 3d6 fire damage on a failed save, or half as much damage on a successful one.

The fire ignites any flammable objects in the area that aren''t being worn or carried.','When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d6 for each slot level above 1st.','Instantaneous','1 action','Burning Hands',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),1,'Self (15 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A storm cloud appears in the shape of a cylinder that is 10 feet tall with a 60-foot radius, centered on a point you can see within range directly above you. The spell fails if you can''t see a point in the air where the storm cloud could appear (for example, if you are in a room that can''t accommodate the cloud).

When you cast the spell, choose a point you can see under the cloud. A bolt of lightning flashes down from the cloud to that point. Each creature within 5 feet of that point must make a Dexterity saving throw. A creature takes 3d10 lightning damage on a failed save, or half as much damage on a successful one. On each of your turns until the spell ends, you can use your action to call down lightning in this way again, targeting the same point or a different one.

If you are outdoors in stormy conditions when you cast this spell, the spell gives you control over the existing storm instead of creating a new one. Under such conditions, the spell''s damage increases by 1d10.','When you cast this spell using a spell slot of 4th or higher level, the damage increases by 1d10 for each slot level above 3rd.','10 minutes','1 action','Call Lightning',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),3,'120 feet (60 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You attempt to suppress strong emotions in a group of people. Each humanoid in a 20-foot-radius sphere centered on a point you choose within range must make a Charisma saving throw; a creature can choose to fail this saving throw if it wishes. If a creature fails its saving throw, choose one of the following two effects.

You can suppress any effect causing a target to be charmed or frightened. When this spell ends, any suppressed effect resumes, provided that its duration has not expired in the meantime.

Alternatively, you can make a target indifferent about creatures of your choice that it is hostile toward. This indifference ends if the target is attacked or harmed by a spell or if it witnesses any of its friends being harmed. When the spell ends, the creature becomes hostile again, unless the DM rules otherwise.',NULL,'1 minute','1 action','Calm Emotions',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),2,'60 feet (20 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create a bolt of lightning that arcs toward a target of your choice that you can see within range. Three bolts then leap from that target to as many as three other targets, each of which must be within 30 feet of the first target. A target can be a creature or an object and can be targeted by only one of the bolts.

A target must make a Dexterity saving throw. The target takes 10d8 lightning damage on a failed save, or half as much damage on a successful one.','When you cast this spell using a spell slot of 7th level or higher, one additional bolt leaps from the first target to another target for each slot level above 6th.','Instantaneous','1 action','Chain Lightning',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),6,'150 feet','A bit of fur; a piece of amber, glass, or a crystal rod; and three silver pins',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You attempt to charm a humanoid you can see within range. It must make a Wisdom saving throw, and does so with advantage if you or your companions are fighting it. If it fails the saving throw, it is charmed by you until the spell ends or until you or your companions do anything harmful to it. The charmed creature regards you as a friendly acquaintance. When the spell ends, the creature knows it was charmed by you.','When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st. The creatures must be within 30 feet of each other when you target them.','1 hour','1 action','Charm Person',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),1,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create a ghostly, skeletal hand in the space of a creature within range. Make a ranged spell attack against the creature to assail it with the chill of the grave. On a hit, the target takes 1d8 necrotic damage, and it can''t regain hit points until the start of your next turn. Until then, the hand clings to the target.

If you hit an undead target, it also has disadvantage on attack rolls against you until the end of your next turn.','This spell''s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).','1 round','1 action','Chill Touch',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),0,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A sphere of negative energy ripples out in a 60-foot-radius sphere from a point within range. Each creature in that area must make a Constitution saving throw. A target takes 8d6 necrotic damage on a failed save, or half as much damage on a successful one.','When you cast this spell using a spell slot of 7th level or higher, the damage increases by 2d6 for each slot level above 6th.','Instantaneous','1 action','Circle of Death',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),6,'150 feet (60 feet)','The powder of a crushed black pearl worth at least 500 gp',500,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create an invisible sensor within range in a location familiar to you (a place you have visited or seen before) or in an obvious location that is unfamiliar to you (such as behind a door, around a corner, or in a grove of trees). The sensor remains in place for the duration, and it can''t be attacked or otherwise interacted with.

When you cast the spell, you choose seeing or hearing. You can use the chosen sense through the sensor as if you were in its space. As your action, you can switch between seeing and hearing.

A creature that can see the sensor (such as a creature benefiting from see invisibility or truesight) sees a luminous, intangible orb about the size of your fist.',NULL,'10 minutes','10 minutes','Clairvoyance',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),3,'1 mile','A focus worth at least 100 gp, either a jeweled horn for hearing or a glass eye for seeing',100,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'This spell grows an inert duplicate of a living, Medium creature as a safeguard against death. This clone forms inside a sealed vessel and grows to full size and maturity after 120 days; you can also choose to have the clone be a younger version of the same creature. It remains inert and endures indefinitely, as long as its vessel remains undisturbed.

At any time after the clone matures, if the original creature dies, its soul transfers to the clone, provided that the soul is free and willing to return. The clone is physically identical to the original and has the same personality, memories, and abilities, but none of the original''s equipment. The original creature''s physical remains, if they still exist, become inert and can''t thereafter be restored to life, since the creature''s soul is elsewhere.',NULL,'Instantaneous','1 hour','Clone',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),8,'Touch','A diamond worth at least 1,000 gp and at least 1 cubic inch of flesh of the creature that is to be cloned, which the spell consumes, and a vessel worth at least 2,000 gp that has a sealable lid and is large enough to hold a Medium creature, such as a huge urn, coffin, mud-filled cyst in the ground, or crystal container filled with salt water',3000,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create a 20-foot-radius sphere of poisonous, yellow-green fog centered on a point you choose within range. The fog spreads around corners. It lasts for the duration or until strong wind disperses the fog, ending the spell. Its area is heavily obscured.

When a creature enters the spell''s area for the first time on a turn or starts its turn there, that creature must make a Constitution saving throw. The creature takes 5d8 poison damage on a failed save, or half as much damage on a successful one. Creatures are affected even if they hold their breath or don''t need to breathe.

The fog moves 10 feet away from you at the start of each of your turns, rolling along the surface of the ground. The vapors, being heavier than air, sink to the lowest level of the land, even pouring down openings.','When you cast this spell using a spell slot of 6th level or higher, the damage increases by 1d8 for each slot level above 5th.','10 minutes','1 action','Cloudkill',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),5,'120 feet (20 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A dazzling array of flashing, colored light springs from your hand. Roll 6d10; the total is how many hit points of creatures this spell can affect. Creatures in a 15-foot cone originating from you are affected in ascending order of their current hit points (ignoring unconscious creatures and creatures that can''t see).

Starting with the creature that has the lowest current hit points, each creature affected by this spell is blinded until the end of your next turn. Subtract each creature''s hit points from the total before moving on to the creature with the next lowest hit points. A creature''s hit points must be equal to or less than the remaining total for that creature to be affected.','When you cast this spell using a spell slot of 2nd level or higher, roll an additional 2d10 for each slot level above 1st.','1 round','1 action','Color Spray',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),1,'Self (15 feet)','A pinch of powder or sand that is colored red, yellow, and blue',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You speak a one-word command to a creature you can see within range. The target must succeed on a Wisdom saving throw or follow the command on its next turn. The spell has no effect if the target is undead, if it doesn''t understand your language, or if your command is directly harmful to it.

Some typical commands and their effects follow. You might issue a command other than one described here. If you do so, the DM determines how the target behaves. If the target can''t follow your command, the spell ends.

Approach. The target moves toward you by the shortest and most direct route, ending its turn if it moves within 5 feet of you.

Drop. The target drops whatever it is holding and then ends its turn.

Flee. The target spends its turn moving away from you by the fastest available means.

Grovel. The target falls prone and then ends its turn.

Halt. The target doesn''t move and takes no actions. A flying creature stays aloft, provided that it is able to do so. If it must move to stay aloft, it flies the minimum distance needed to remain in the air.','When you cast this spell using a spell slot of 2nd level or higher, you can affect one additional creature for each slot level above 1st. The creatures must be within 30 feet of each other when you target them.','1 round','1 action','Command',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),1,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You contact your deity or a divine proxy and ask up to three questions that can be answered with a yes or no. You must ask your questions before the spell ends. You receive a correct answer for each question.

Divine beings aren''t necessarily omniscient, so you might receive "unclear" as an answer if a question pertains to information that lies beyond the deity''s knowledge. In a case where a one-word answer could be misleading or contrary to the deity''s interests, the DM might offer a short phrase as an answer instead.

If you cast the spell two or more times before finishing your next long rest, there is a cumulative 25 percent chance for each casting after the first that you get no answer. The DM makes this roll in secret.',NULL,'1 minute','1 minute','Commune',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),5,'Self','Incense and a vial of holy or unholy water',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You briefly become one with nature and gain knowledge of the surrounding territory. In the outdoors, the spell gives you knowledge of the land within 3 miles of you. In caves and other natural underground settings, the radius is limited to 300 feet. The spell doesn''t function where nature has been replaced by construction, such as in dungeons and towns.

You instantly gain knowledge of up to three facts of your choice about any of the following subjects as they relate to the area:

- terrain and bodies of water
- prevalent plants, minerals, animals, or peoples
- powerful celestials, fey, fiends, elementals, or undead
- influence from other planes of existence
- buildings

For example, you could determine the location of powerful undead in the area, the location of major sources of safe drinking water, and the location of any nearby towns.',NULL,'Instantaneous','1 minute','Commune with Nature',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),5,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'For the duration, you understand the literal meaning of any spoken language that you hear. You also understand any written language that you see, but you must be touching the surface on which the words are written. It takes about 1 minute to read one page of text.

This spell doesn''t decode secret messages in a text or a glyph, such as an arcane sigil, that isn''t part of a written language.',NULL,'1 hour','1 action','Comprehend Languages',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),1,'Self','A pinch of soot and salt',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Creatures of your choice that you can see within range and that can hear you must make a Wisdom saving throw. A target automatically succeeds on this saving throw if it can''t be charmed. On a failed save, a target is affected by this spell. Until the spell ends, you can use a bonus action on each of your turns to designate a direction that is horizontal to you. Each affected target must use as much of its movement as possible to move in that direction on its next turn. It can take its action before it moves. After moving in this way, it can make another Wisdom saving throw to try to end the effect.

A target isn''t compelled to move into an obviously deadly hazard, such as a fire or pit, but it will provoke opportunity attacks to move in the designated direction.',NULL,'1 minute','1 action','Compulsion',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),4,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A blast of cold air erupts from your hands. Each creature in a 60-foot cone must make a Constitution saving throw. A creature takes 8d8 cold damage on a failed save, or half as much damage on a successful one.

A creature killed by this spell becomes a frozen statue until it thaws.','When you cast this spell using a spell slot of 6th level or higher, the damage increases by 1d8 for each slot level above 5th.','Instantaneous','1 action','Cone of Cold',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),5,'Self (60 feet)','A small crystal or glass cone',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'This spell assaults and twists creatures'' minds, spawning delusions and provoking uncontrolled action. Each creature in a 10-foot-radius sphere centered on a point you choose within range must succeed on a Wisdom saving throw when you cast this spell or be affected by it.

An affected target can''t take reactions and must roll a d10 at the start of each of its turns to determine its behavior for that turn.

d10     |Behavior
1       |The creature uses all its movement to move in a random direction. To determine the direction, roll a d8 and assign a direction to each die face. The creature doesn''t take an action this turn.
2–6     |The creature doesn''t move or take actions this turn.
7–8     |The creature uses its action to make a melee attack against a randomly determined creature within its reach. If there is no creature within its reach, the creature does nothing this turn.
9–10    |The creature can act and move normally.

At the end of each of its turns, an affected target can make a Wisdom saving throw. If it succeeds, this effect ends for that target.','When you cast this spell using a spell slot of 5th level or higher, the radius of the sphere increases by 5 feet for each slot level above 4th.','1 minute','1 action','Confusion',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),4,'90 feet (10 feet)','Three nut shells',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You summon fey spirits that take the form of beasts and appear in unoccupied spaces that you can see within range. Choose one of the following options for what appears:

- One beast of challenge rating 2 or lower
- Two beasts of challenge rating 1 or lower
- Four beasts of challenge rating 1/2 or lower
- Eight beasts of challenge rating 1/4 or lower

Each beast is also considered fey, and it disappears when it drops to 0 hit points or when the spell ends.

The summoned creatures are friendly to you and your companions. Roll initiative for the summoned creatures as a group, which has its own turns. They obey any verbal commands that you issue to them (no action required by you). If you don''t issue any commands to them, they defend themselves from hostile creatures, but otherwise take no actions.

The DM has the creatures'' statistics.','When you cast this spell using certain higher-level spell slots, you choose one of the summoning options above, and more creatures appear: twice as many with a 5th-level slot, three times as many with a 7th-level slot, and four times as many with a 9th-level slot.','1 hour','1 action','Conjure Animals',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),3,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You summon a celestial of challenge rating 4 or lower, which appears in an unoccupied space that you can see within range. The celestial disappears when it drops to 0 hit points or when the spell ends.

The celestial is friendly to you and your companions for the duration. Roll initiative for the celestial, which has its own turns. It obeys any verbal commands that you issue to it (no action required by you), as long as they don''t violate its alignment. If you don''t issue any commands to the celestial, it defends itself from hostile creatures but otherwise takes no actions.

The DM has the celestial''s statistics.','When you cast this spell using a 9th-level spell slot, you summon a celestial of challenge rating 5 or lower.','1 hour','1 minute','Conjure Celestial',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),7,'90 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You call forth an elemental servant. Choose an area of air, earth, fire, or water that fills a 10-foot cube within range. An elemental of challenge rating 5 or lower appropriate to the area you chose appears in an unoccupied space within 10 feet of it. For example, a fire elemental emerges from a bonfire, and an earth elemental rises up from the ground. The elemental disappears when it drops to 0 hit points or when the spell ends.

The elemental is friendly to you and your companions for the duration. Roll initiative for the elemental, which has its own turns. It obeys any verbal commands that you issue to it (no action required by you). If you don''t issue any commands to the elemental, it defends itself from hostile creatures but otherwise takes no actions.

If your concentration is broken, the elemental doesn''t disappear. Instead, you lose control of the elemental, it becomes hostile toward you and your companions, and it might attack. An uncontrolled elemental can''t be dismissed by you, and it disappears 1 hour after you summoned it.

The DM has the elemental''s statistics.','When you cast this spell using a spell slot of 6th level or higher, the challenge rating increases by 1 for each slot level above 5th.','1 hour','1 minute','Conjure Elemental',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),5,'90 feet','Burning incense for air, soft clay for earth, sulfur and phosphorus for fire, or water and sand for water',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You summon a fey creature of challenge rating 6 or lower, or a fey spirit that takes the form of a beast of challenge rating 6 or lower. It appears in an unoccupied space that you can see within range. The fey creature disappears when it drops to 0 hit points or when the spell ends.

The fey creature is friendly to you and your companions for the duration. Roll initiative for the creature, which has its own turns. It obeys any verbal commands that you issue to it (no action required by you), as long as they don''t violate its alignment. If you don''t issue any commands to the fey creature, it defends itself from hostile creatures but otherwise takes no actions.

If your concentration is broken, the fey creature doesn''t disappear. Instead, you lose control of the fey creature, it becomes hostile toward you and your companions, and it might attack. An uncontrolled fey creature can''t be dismissed by you, and it disappears 1 hour after you summoned it.

The DM has the fey creature''s statistics.','When you cast this spell using a spell slot of 7th level or higher, the challenge rating increases by 1 for each slot level above 6th.','1 hour','1 minute','Conjure Fey',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),6,'90 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You summon elementals that appear in unoccupied spaces that you can see within range. You choose one the following options for what appears:

- One elemental of challenge rating 2 or lower
- Two elementals of challenge rating 1 or lower
- Four elementals of challenge rating 1/2 or lower
- Eight elementals of challenge rating 1/4 or lower.

An elemental summoned by this spell disappears when it drops to 0 hit points or when the spell ends.

The summoned creatures are friendly to you and your companions. Roll initiative for the summoned creatures as a group, which has its own turns. They obey any verbal commands that you issue to them (no action required by you). If you don''t issue any commands to them, they defend themselves from hostile creatures, but otherwise take no actions.

The DM has the creatures'' statistics.','When you cast this spell using certain higher-level spell slots, you choose one of the summoning options above, and more creatures appear: twice as many with a 6th-level slot and three times as many with an 8th-level slot.','1 hour','1 minute','Conjure Minor Elementals',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),4,'90 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You summon fey creatures that appear in unoccupied spaces that you can see within range. Choose one of the following options for what appears:

- One fey creature of challenge rating 2 or lower
- Two fey creatures of challenge rating 1 or lower
- Four fey creatures of challenge rating 1/2 or lower
- Eight fey creatures of challenge rating 1/4 or lower

A summoned creature disappears when it drops to 0 hit points or when the spell ends.

The summoned creatures are friendly to you and your companions. Roll initiative for the summoned creatures as a group, which have their own turns. They obey any verbal commands that you issue to them (no action required by you). If you don''t issue any commands to them, they defend themselves from hostile creatures, but otherwise take no actions.

The DM has the creatures'' statistics.','When you cast this spell using certain higher-level spell slots, you choose one of the summoning options above, and more creatures appear: twice as many with a 6th-level slot and three times as many with an 8th-level slot.','1 hour','1 action','Conjure Woodland Beings',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),4,'60 feet','One holly berry per creature summoned',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You mentally contact a demigod, the spirit of a long-dead sage, or some other mysterious entity from another plane. Contacting this extraplanar intelligence can strain or even break your mind. When you cast this spell, make a DC 15 Intelligence saving throw. On a failure, you take 6d6 psychic damage and are insane until you finish a long rest. While insane, you can''t take actions, can''t understand what other creatures say, can''t read, and speak only in gibberish. A greater restoration spell cast on you ends this effect.

On a successful save, you can ask the entity up to five questions. You must ask your questions before the spell ends. The DM answers each question with one word, such as "yes," "no," "maybe," "never," "irrelevant," or "unclear" (if the entity doesn''t know the answer to the question). If a one-word answer would be misleading, the DM might instead offer a short phrase as an answer.',NULL,'1 minute','1 minute','Contact Other Plane',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),5,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Your touch inflicts disease. Make a melee spell attack against a creature within your reach. On a hit, the target is poisoned.

At the end of each of the poisoned target''s turns, the target must make a Constitution saving throw. If the target succeeds on three of these saves, it is no longer poisoned, and the spell ends. If the target fails three of these saves, the target is no longer poisoned, but choose one of the diseases below. The target is subjected to the chosen disease for the spell''s duration.

Since this spell induces a natural disease in its target, any effect that removes a disease or otherwise ameliorates a disease''s effects apply to it.

Blinding Sickness. Pain grips the creature''s mind, and its eyes turn milky white. The creature has disadvantage on Wisdom checks and Wisdom saving throws and is blinded.

Filth Fever. A raging fever sweeps through the creature''s body. The creature has disadvantage on Strength checks, Strength saving throws, and attack rolls that use Strength.

Flesh Rot. The creature''s flesh decays. The creature has disadvantage on Charisma checks and vulnerability to all damage.

Mindfire. The creature''s mind becomes feverish. The creature has disadvantage on Intelligence checks and Intelligence saving throws, and the creature behaves as if under the effects of the confusion spell during combat.

Seizure. The creature is overcome with shaking. The creature has disadvantage on Dexterity checks, Dexterity saving throws, and attack rolls that use Dexterity.

Slimy Doom. The creature begins to bleed uncontrollably. The creature has disadvantage on Constitution checks and Constitution saving throws. In addition, whenever the creature takes damage, it is stunned until the end of its next turn.',NULL,'7 days','1 action','Contagion',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),5,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Choose a spell of 5th level or lower that you can cast, that has a casting time of 1 action, and that can target you. You cast that spell—called the contingent spell—as part of casting contingency, expending spell slots for both, but the contingent spell doesn''t come into effect. Instead, it takes effect when a certain circumstance occurs. You describe that circumstance when you cast the two spells. For example, a contingency cast with water breathing might stipulate that water breathing comes into effect when you are engulfed in water or a similar liquid.

The contingent spell takes effect immediately after the circumstance is met for the first time, whether or not you want it to, and then contingency ends.

The contingent spell takes effect only on you, even if it can normally target others. You can use only one contingency spell at a time. If you cast this spell again, the effect of another contingency spell on you ends. Also, contingency ends on you if its material component is ever not on your person.',NULL,'10 days','10 minutes','Contingency',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),6,'Self','A statuette of yourself carved from ivory and decorated with gems worth at least 1,500 gp',1500,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A flame, equivalent in brightness to a torch, springs forth from an object that you touch. The effect looks like a regular flame, but it creates no heat and doesn''t use oxygen. A continual flame can be covered or hidden but not smothered or quenched.',NULL,'Until Dispelled','1 action','Continual Flame',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),2,'Touch','Ruby dust worth 50 gp, which the spell consumes',50,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Until the spell ends, you control any freestanding water inside an area you choose that is a cube up to 100 feet on a side. You can choose from any of the following effects when you cast this spell. As an action on your turn, you can repeat the same effect or choose a different one.

Flood. You cause the water level of all standing water in the area to rise by as much as 20 feet. If the area includes a shore, the flooding water spills over onto dry land.

If you choose an area in a large body of water, you instead create a 20-foot tall wave that travels from one side of the area to the other and then crashes down. Any Huge or smaller vehicles in the wave''s path are carried with it to the other side. Any Huge or smaller vehicles struck by the wave have a 25 percent chance of capsizing.

The water level remains elevated until the spell ends or you choose a different effect. If this effect produced a wave, the wave repeats on the start of your next turn while the flood effect lasts.

Part Water. You cause water in the area to move apart and create a trench. The trench extends across the spell''s area, and the separated water forms a wall to either side. The trench remains until the spell ends or you choose a different effect. The water then slowly fills in the trench over the course of the next round until the normal water level is restored.

Redirect Flow. You cause flowing water in the area to move in a direction you choose, even if the water has to flow over obstacles, up walls, or in other unlikely directions. The water in the area moves as you direct it, but once it moves beyond the spell''s area, it resumes its flow based on the terrain conditions. The water continues to move in the direction you chose until the spell ends or you choose a different effect.

Whirlpool. This effect requires a body of water at least 50 feet square and 25 feet deep. You cause a whirlpool to form in the center of the area. The whirlpool forms a vortex that is 5 feet wide at the base, up to 50 feet wide at the top, and 25 feet tall. Any creature or object in the water and within 25 feet of the vortex is pulled 10 feet toward it. A creature can swim away from the vortex by making a Strength (Athletics) check against your spell save DC.

When a creature enters the vortex for the first time on a turn or starts its turn there, it must make a Strength saving throw. On a failed save, the creature takes 2d8 bludgeoning damage and is caught in the vortex until the spell ends. On a successful save, the creature takes half damage, and isn''t caught in the vortex. A creature caught in the vortex can use its action to try to swim away from the vortex as described above, but has disadvantage on the Strength (Athletics) check to do so.

The first time each turn that an object enters the vortex, the object takes 2d8 bludgeoning damage; this damage occurs each round it remains in the vortex.',NULL,'10 minutes','1 action','Control Water',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),4,'300 feet','A drop of water and a pinch of dust',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You take control of the weather within 5 miles of you for the duration. You must be outdoors to cast this spell. Moving to a place where you don''t have a clear path to the sky ends the spell early.

When you cast the spell, you change the current weather conditions, which are determined by the DM based on the climate and season. You can change precipitation, temperature, and wind. It takes 1d4 × 10 minutes for the new conditions to take effect. Once they do so, you can change the conditions again. When the spell ends, the weather gradually returns to normal.

When you change the weather conditions, find a current condition on the following tables and change its stage by one, up or down. When changing the wind, you can change its direction.

Temperature
Stage   |Condition
1       |Unbearable heat
2       |Hot
3       |Warm
4       |Cool
5       |Cold
6       |Arctic cold

Wind
Stage   |Condition
1       |Calm
2       |Moderate wind
3       |Strong wind
4       |Gale
5       |Storm

Precipitation
Stage   |Condition
1       |Clear
2       |Light clouds
3       |Overcast or ground fog
4       |Rain, hail, or snow
5       |Torrential rain, driving hail, or blizzard',NULL,'8 hours','10 minutes','Control Weather',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),8,'Self (5 miles)','Burning incense and bits of earth and wood mixed in water',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You attempt to interrupt a creature in the process of casting a spell. If the creature is casting a spell of 3rd level or lower, its spell fails and has no effect. If it is casting a spell of 4th level or higher, make an ability check using your spellcasting ability. The DC equals 10 + the spell''s level. On a success, the creature''s spell fails and has no effect.','When you cast this spell using a spell slot of 4th level or higher, the interrupted spell has no effect if its level is less than or equal to the level of the spell slot you used.','Instantaneous','1 reaction','Counterspell',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),3,'60 feet',NULL,NULL,'which you take when you see a creature within 60 feet of you casting a spell');
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create 45 pounds of food and 30 gallons of water on the ground or in containers within range, enough to sustain up to fifteen humanoids or five steeds for 24 hours. The food is bland but nourishing, and spoils if uneaten after 24 hours. The water is clean and doesn''t go bad.',NULL,'Instantaneous','1 action','Create Food and Water',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),3,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You either create or destroy water.

Create Water. You create up to 10 gallons of clean water within range in an open container. Alternatively, the water falls as rain in a 30-foot cube within range, extinguishing exposed flames in the area.

Destroy Water. You destroy up to 10 gallons of water in an open container within range. Alternatively, you destroy fog in a 30-foot cube within range.','When you cast this spell using a spell slot of 2nd level or higher, you create or destroy 10 additional gallons of water, or the size of the cube increases by 5 feet, for each slot level above 1st.','Instantaneous','1 action','Create or Destroy Water',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),1,'30 feet (30 feet)','A drop of water if creating water or a few grains of sand if destroying it',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You can cast this spell only at night. Choose up to three corpses of Medium or Small humanoids within range. Each corpse becomes a ghoul under your control. (The DM has game statistics for these creatures.)

As a bonus action on each of your turns, you can mentally command any creature you animated with this spell if the creature is within 120 feet of you (if you control multiple creatures, you can command any or all of them at the same time, issuing the same command to each one). You decide what action the creature will take and where it will move during its next turn, or you can issue a general command, such as to guard a particular chamber or corridor. If you issue no commands, the creature only defends itself against hostile creatures. Once given an order, the creature continues to follow it until its task is complete.

The creature is under your control for 24 hours, after which it stops obeying any command you have given it. To maintain control of the creature for another 24 hours, you must cast this spell on the creature before the current 24-hour period ends. This use of the spell reasserts your control over up to three creatures you have animated with this spell, rather than animating new ones.','When you cast this spell using a 7th-level spell slot, you can animate or reassert control over four ghouls. When you cast this spell using an 8th-level spell slot, you can animate or reassert control over five ghouls or two ghasts or wights. When you cast this spell using a 9th-level spell slot, you can animate or reassert control over six ghouls, three ghasts or wights, or two mummies.','Instantaneous','1 minute','Create Undead',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),6,'10 feet','One clay pot filled with grave dirt, one clay pot filled with brackish water, and one 150 gp black onyx stone for each corpse',150,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You pull wisps of shadow material from the Shadowfell to create a nonliving object of vegetable matter within range: soft goods, rope, wood, or something similar. You can also use this spell to create mineral objects such as stone, crystal, or metal. The object created must be no larger than a 5-foot cube, and the object must be of a form and material that you have seen before.

The duration depends on the object''s material. If the object is composed of multiple materials, use the shortest duration.

Material                |Duration
Vegetable matter        |1 day
Stone or crystal        |12 hours
Precious metals         |1 hour
Gems                    |10 minutes
Adamantine or mithral   |1 minute

Using any material created by this spell as another spell''s material component causes that spell to fail.','When you cast this spell using a spell slot of 6th level or higher, the cube increases by 5 feet for each slot level above 5th.','Special','1 minute','Creation',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),5,'30 feet (5 feet)','A tiny piece of matter of the same type of the item you plan to create',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A creature you touch regains a number of hit points equal to 1d8 + your spellcasting ability modifier. This spell has no effect on undead or constructs.','When you cast this spell using a spell slot of 2nd level or higher, the healing increases by 1d8 for each slot level above 1st.','Instantaneous','1 action','Cure Wounds',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),1,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create up to four torch-sized lights within range, making them appear as torches, lanterns, or glowing orbs that hover in the air for the duration. You can also combine the four lights into one glowing vaguely humanoid form of Medium size. Whichever form you choose, each light sheds dim light in a 10-foot radius.

As a bonus action on your turn, you can move the lights up to 60 feet to a new spot within range. A light must be within 20 feet of another light created by this spell, and a light winks out if it exceeds the spell''s range.',NULL,'1 minute','1 action','Dancing Lights',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),0,'120 feet','A bit of phosphorus or wychwood, or a glowworm',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Magical darkness spreads from a point you choose within range to fill a 15-foot-radius sphere for the duration. The darkness spreads around corners. A creature with darkvision can''t see through this darkness, and nonmagical light can''t illuminate it.

If the point you choose is on an object you are holding or one that isn''t being worn or carried, the darkness emanates from the object and moves with it. Completely covering the source of the darkness with an opaque object, such as a bowl or a helm, blocks the darkness.

If any of this spell''s area overlaps with an area of light created by a spell of 2nd level or lower, the spell that created the light is dispelled.',NULL,'10 minutes','1 action','Darkness',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),2,'60 feet (15 feet)','Bat fur and a drop of pitch or piece of coal',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a willing creature to grant it the ability to see in the dark. For the duration, that creature has darkvision out to a range of 60 feet.',NULL,'8 hours','1 action','Darkvision',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'Touch','Either a pinch of dried carrot or an agate',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A 60-foot-radius sphere of light spreads out from a point you choose within range. The sphere is bright light and sheds dim light for an additional 60 feet.

If you chose a point on an object you are holding or one that isn''t being worn or carried, the light shines from the object and moves with it. Completely covering the affected object with an opaque object, such as a bowl or a helm, blocks the light.

If any of this spell''s area overlaps with an area of darkness created by a spell of 3rd level or lower, the spell that created the darkness is dispelled.',NULL,'1 hour','1 action','Daylight',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),3,'60 feet (60 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a creature and grant it a measure of protection from death.

The first time the target would drop to 0 hit points as a result of taking damage, the target instead drops to 1 hit point, and the spell ends.

If the spell is still in effect when the target is subjected to an effect that would kill it instantaneously without dealing damage, that effect is instead negated against the target, and the spell ends.',NULL,'8 hours','1 action','Death Ward',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),4,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A beam of yellow light flashes from your pointing finger, then condenses to linger at a chosen point within range as a glowing bead for the duration. When the spell ends, either because your concentration is broken or because you decide to end it, the bead blossoms with a low roar into an explosion of flame that spreads around corners. Each creature in a 20-foot-radius sphere centered on that point must make a Dexterity saving throw. A creature takes fire damage equal to the total accumulated damage on a failed save, or half as much damage on a successful one.

The spell''s base damage is 12d6. If at the end of your turn the bead has not yet detonated, the damage increases by 1d6.

If the glowing bead is touched before the interval has expired, the creature touching it must make a Dexterity saving throw. On a failed save, the spell ends immediately, causing the bead to erupt in flame. On a successful save, the creature can throw the bead up to 40 feet. When it strikes a creature or a solid object, the spell ends, and the bead explodes.

The fire damages objects in the area and ignites flammable objects that aren''t being worn or carried.','When you cast this spell using a spell slot of 8th level or higher, the base damage increases by 1d6 for each slot level above 7th.','1 minute','1 action','Delayed Blast Fireball',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),7,'150 feet (20 feet)','A tiny ball of bat guano and sulfur',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create a shadowy door on a flat solid surface that you can see within range. The door is large enough to allow Medium creatures to pass through unhindered. When opened, the door leads to a demiplane that appears to be an empty room 30 feet in each dimension, made of wood or stone. When the spell ends, the door disappears, and any creatures or objects inside the demiplane remain trapped there, as the door also disappears from the other side.

Each time you cast this spell, you can create a new demiplane, or have the shadowy door connect to a demiplane you created with a previous casting of this spell. Additionally, if you know the nature and contents of a demiplane created by a casting of this spell by another creature, you can have the shadowy door connect to its demiplane instead.',NULL,'1 hour','1 action','Demiplane',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),8,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'For the duration, you know if there is an aberration, celestial, elemental, fey, fiend, or undead within 30 feet of you, as well as where the creature is located. Similarly, you know if there is a place or object within 30 feet of you that has been magically consecrated or desecrated.

The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.',NULL,'10 minutes','1 action','Detect Evil and Good',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),1,'Self (30 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'For the duration, you sense the presence of magic within 30 feet of you. If you sense magic in this way, you can use your action to see a faint aura around any visible creature or object in the area that bears magic, and you learn its school of magic, if any.

The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.',NULL,'10 minutes','1 action','Detect Magic',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),1,'Self (30 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'For the duration, you can sense the presence and location of poisons, poisonous creatures, and diseases within 30 feet of you. You also identify the kind of poison, poisonous creature, or disease in each case.

The spell can penetrate most barriers, but it is blocked by 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood or dirt.',NULL,'10 minutes','1 action','Detect Poison and Disease',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),1,'Self (30 feet)','A yew leaf',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'For the duration, you can read the thoughts of certain creatures. When you cast the spell and as your action on each turn until the spell ends, you can focus your mind on any one creature that you can see within 30 feet of you. If the creature you choose has an Intelligence of 3 or lower or doesn''t speak any language, the creature is unaffected.

You initially learn the surface thoughts of the creature—what is most on its mind in that moment. As an action, you can either shift your attention to another creature''s thoughts or attempt to probe deeper into the same creature''s mind. If you probe deeper, the target must make a Wisdom saving throw. If it fails, you gain insight into its reasoning (if any), its emotional state, and something that looms large in its mind (such as something it worries over, loves, or hates). If it succeeds, the spell ends. Either way, the target knows that you are probing into its mind, and unless you shift your attention to another creature''s thoughts, the creature can use its action on its turn to make an Intelligence check contested by your Intelligence check; if it succeeds, the spell ends.

Questions verbally directed at the target creature naturally shape the course of its thoughts, so this spell is particularly effective as part of an interrogation.

You can also use this spell to detect the presence of thinking creatures you can''t see. When you cast the spell or as your action during the duration, you can search for thoughts within 30 feet of you. The spell can penetrate barriers, but 2 feet of rock, 2 inches of any metal other than lead, or a thin sheet of lead blocks you. You can''t detect a creature with an Intelligence of 3 or lower or one that doesn''t speak any language.

Once you detect the presence of a creature in this way, you can read its thoughts for the rest of the duration as described above, even if you can''t see it, but it must still be within range.',NULL,'1 minute','1 action','Detect Thoughts',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),2,'Self','A copper piece',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You teleport yourself from your current location to any other spot within range. You arrive at exactly the spot desired. It can be a place you can see, one you can visualize, or one you can describe by stating distance and direction, such as "200 feet straight downward" or "upward to the northwest at a 45-degree angle, 300 feet."

You can bring along objects as long as their weight doesn''t exceed what you can carry. You can also bring one willing creature of your size or smaller who is carrying gear up to its carrying capacity. The creature must be within 5 feet of you when you cast this spell.

If you would arrive in a place already occupied by an object or a creature, you and any creature traveling with you each take 4d6 force damage, and the spell fails to teleport you.',NULL,'Instantaneous','1 action','Dimension Door',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),4,'500 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You make yourself—including your clothing, armor, weapons, and other belongings on your person—look different until the spell ends or until you use your action to dismiss it. You can seem 1 foot shorter or taller and can appear thin, fat, or in between. You can''t change your body type, so you must adopt a form that has the same basic arrangement of limbs. Otherwise, the extent of the illusion is up to you.

The changes wrought by this spell fail to hold up to physical inspection. For example, if you use this spell to add a hat to your outfit, objects pass through the hat, and anyone who touches it would feel nothing or would feel your head and hair. If you use this spell to appear thinner than you are, the hand of someone who reaches out to touch you would bump into you while it was seemingly still in midair.

To discern that you are disguised, a creature can use its action to inspect your appearance and must succeed on an Intelligence (Investigation) check against your spell save DC.',NULL,'1 hour','1 action','Disguise Self',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),1,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A thin green ray springs from your pointing finger to a target that you can see within range. The target can be a creature, an object, or a creation of magical force, such as the wall created by wall of force.

A creature targeted by this spell must make a Dexterity saving throw. On a failed save, the target takes 10d6 + 40 force damage. The target is disintegrated if this damage leaves it with 0 hit points.

A disintegrated creature and everything it is wearing and carrying, except magic items, are reduced to a pile of fine gray dust. The creature can be restored to life only by means of a true resurrection or a wish spell.

This spell automatically disintegrates a Large or smaller nonmagical object or a creation of magical force. If the target is a Huge or larger object or creation of force, this spell disintegrates a 10-foot-cube portion of it. A magic item is unaffected by this spell.','When you cast this spell using a spell slot of 7th level or higher, the damage increases by 3d6 for each slot level above 6th.','Instantaneous','1 action','Disintegrate',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),6,'60 feet','A lodestone and a pinch of dust',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Shimmering energy surrounds and protects you from fey, undead, and creatures originating from beyond the Material Plane. For the duration, celestials, elementals, fey, fiends, and undead have disadvantage on attack rolls against you.

You can end the spell early by using either of the following special functions.

Break Enchantment. As your action, you touch a creature you can reach that is charmed, frightened, or possessed by a celestial, an elemental, a fey, a fiend, or an undead. The creature you touch is no longer charmed, frightened, or possessed by such creatures.

Dismissal. As your action, make a melee spell attack against a celestial, an elemental, a fey, a fiend, or an undead you can reach. On a hit, you attempt to drive the creature back to its home plane. The creature must succeed on a Charisma saving throw or be sent back to its home plane (if it isn''t there already). If they aren''t on their home plane, undead are sent to the Shadowfell, and fey are sent to the Feywild.',NULL,'1 minute','1 action','Dispel Evil and Good',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),5,'Self','Holy water or powdered silver and iron',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Choose one creature, object, or magical effect within range. Any spell of 3rd level or lower on the target ends. For each spell of 4th level or higher on the target, make an ability check using your spellcasting ability. The DC equals 10 + the spell''s level. On a successful check, the spell ends.','When you cast this spell using a spell slot of 4th level or higher, you automatically end the effects of a spell on the target if the spell''s level is equal to or less than the level of the spell slot you used.','Instantaneous','1 action','Dispel Magic',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),3,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Your magic and an offering put you in contact with a god or a god''s servants. You ask a single question concerning a specific goal, event, or activity to occur within 7 days. The DM offers a truthful reply. The reply might be a short phrase, a cryptic rhyme, or an omen.

The spell doesn''t take into account any possible circumstances that might change the outcome, such as the casting of additional spells or the loss or gain of a companion.

If you cast the spell two or more times before finishing your next long rest, there is a cumulative 25 percent chance for each casting after the first that you get a random reading. The DM makes this roll in secret.',NULL,'Instantaneous','1 action','Divination',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),4,'Self','Incense and a sacrificial offering appropriate to your religion, together worth at least 25 gp, which the spell consumes',25,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Your prayer empowers you with divine radiance. Until the spell ends, your weapon attacks deal an extra 1d4 radiant damage on a hit.',NULL,'1 minute','1 bonus action','Divine Favor',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),1,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You utter a divine word, imbued with the power that shaped the world at the dawn of creation. Choose any number of creatures you can see within range. Each creature that can hear you must make a Charisma saving throw. On a failed save, a creature suffers an effect based on its current hit points:

- 50 hit points or fewer: deafened for 1 minute
- 40 hit points or fewer: deafened and blinded for 10 minutes
- 30 hit points or fewer: blinded, deafened, and stunned for 1 hour
- 20 hit points or fewer: killed instantly

Regardless of its current hit points, a celestial, an elemental, a fey, or a fiend that fails its save is forced back to its plane of origin (if it isn''t there already) and can''t return to your current plane for 24 hours by any means short of a wish spell.',NULL,'Instantaneous','1 bonus action','Divine Word',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),7,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You attempt to beguile a beast that you can see within range. It must succeed on a Wisdom saving throw or be charmed by you for the duration. If you or creatures that are friendly to you are fighting it, it has advantage on the saving throw.

While the beast is charmed, you have a telepathic link with it as long as the two of you are on the same plane of existence. You can use this telepathic link to issue commands to the creature while you are conscious (no action required), which it does its best to obey. You can specify a simple and general course of action, such as "Attack that creature," "Run over there," or "Fetch that object." If the creature completes the order and doesn''t receive further direction from you, it defends and preserves itself to the best of its ability.

You can use your action to take total and precise control of the target. Until the end of your next turn, the creature takes only the actions you choose, and doesn''t do anything that you don''t allow it to do. During this time, you can also cause the creature to use a reaction, but this requires you to use your own reaction as well.

Each time the target takes damage, it makes a new Wisdom saving throw against the spell. If the saving throw succeeds, the spell ends.','When you cast this spell with a 5th-level spell slot, the duration is concentration, up to 10 minutes. When you use a 6th-level spell slot, the duration is concentration, up to 1 hour. When you use a spell slot of 7th level or higher, the duration is concentration, up to 8 hours.','1 minute','1 action','Dominate Beast',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),4,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You attempt to beguile a creature that you can see within range. It must succeed on a Wisdom saving throw or be charmed by you for the duration. If you or creatures that are friendly to you are fighting it, it has advantage on the saving throw.

While the creature is charmed, you have a telepathic link with it as long as the two of you are on the same plane of existence. You can use this telepathic link to issue commands to the creature while you are conscious (no action required), which it does its best to obey. You can specify a simple and general course of action, such as "Attack that creature," "Run over there," or "Fetch that object." If the creature completes the order and doesn''t receive further direction from you, it defends and preserves itself to the best of its ability.

You can use your action to take total and precise control of the target. Until the end of your next turn, the creature takes only the actions you choose, and doesn''t do anything that you don''t allow it to do. During this time, you can also cause the creature to use a reaction, but this requires you to use your own reaction as well.

Each time the target takes damage, it makes a new Wisdom saving throw against the spell. If the saving throw succeeds, the spell ends.','When you cast this spell with a 9th-level spell slot, the duration is concentration, up to 8 hours.','1 hour','1 action','Dominate Monster',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),8,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You attempt to beguile a humanoid that you can see within range. It must succeed on a Wisdom saving throw or be charmed by you for the duration. If you or creatures that are friendly to you are fighting it, it has advantage on the saving throw.

While the target is charmed, you have a telepathic link with it as long as the two of you are on the same plane of existence. You can use this telepathic link to issue commands to the creature while you are conscious (no action required), which it does its best to obey. You can specify a simple and general course of action, such as "Attack that creature," "Run over there," or "Fetch that object." If the creature completes the order and doesn''t receive further direction from you, it defends and preserves itself to the best of its ability.

You can use your action to take total and precise control of the target. Until the end of your next turn, the creature takes only the actions you choose, and doesn''t do anything that you don''t allow it to do. During this time you can also cause the creature to use a reaction, but this requires you to use your own reaction as well.

Each time the target takes damage, it makes a new Wisdom saving throw against the spell. If the saving throw succeeds, the spell ends.','When you cast this spell using a 6th-level spell slot, the duration is concentration, up to 10 minutes. When you use a 7th-level spell slot, the duration is concentration, up to 1 hour. When you use a spell slot of 8th level or higher, the duration is concentration, up to 8 hours.','1 minute','1 action','Dominate Person',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),5,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'This spell shapes a creature''s dreams. Choose a creature known to you as the target of this spell. The target must be on the same plane of existence as you. Creatures that don''t sleep, such as elves, can''t be contacted by this spell. You, or a willing creature you touch, enters a trance state, acting as a messenger. While in the trance, the messenger is aware of his or her surroundings, but can''t take actions or move.

If the target is asleep, the messenger appears in the target''s dreams and can converse with the target as long as it remains asleep, through the duration of the spell. The messenger can also shape the environment of the dream, creating landscapes, objects, and other images. The messenger can emerge from the trance at any time, ending the effect of the spell early. The target recalls the dream perfectly upon waking. If the target is awake when you cast the spell, the messenger knows it, and can either end the trance (and the spell) or wait for the target to fall asleep, at which point the messenger appears in the target''s dreams.

You can make the messenger appear monstrous and terrifying to the target. If you do, the messenger can deliver a message of no more than ten words and then the target must make a Wisdom saving throw. On a failed save, echoes of the phantasmal monstrosity spawn a nightmare that lasts the duration of the target''s sleep and prevents the target from gaining any benefit from that rest. In addition, when the target wakes up, it takes 3d6 psychic damage.

If you have a body part, lock of hair, clipping from a nail, or similar portion of the target''s body, the target makes its saving throw with disadvantage.',NULL,'8 hours','1 minute','Dream',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),5,'Touch','A handful of sand, a dab of ink, and a writing quill plucked from a sleeping bird',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Whispering to the spirits of nature, you create one of the following effects within range:

- You create a tiny, harmless sensory effect that predicts what the weather will be at your location for the next 24 hours. The effect might manifest as a golden orb for clear skies, a cloud for rain, falling snowflakes for snow, and so on. This effect persists for 1 round.
- You instantly make a flower blossom, a seed pod open, or a leaf bud bloom.
- You create an instantaneous, harmless sensory effect, such as falling leaves, a puff of wind, the sound of a small animal, or the faint odor of skunk. The effect must fit in a 5-foot cube.
- You instantly light or snuff out a candle, a torch, or a small campfire.',NULL,'Instantaneous','1 action','Druidcraft',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),0,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create a seismic disturbance at a point on the ground that you can see within range. For the duration, an intense tremor rips through the ground in a 100-foot-radius circle centered on that point and shakes creatures and structures in contact with the ground in that area.

The ground in the area becomes difficult terrain. Each creature on the ground that is concentrating must make a Constitution saving throw. On a failed save, the creature''s concentration is broken.

When you cast this spell and at the end of each turn you spend concentrating on it, each creature on the ground in the area must make a Dexterity saving throw. On a failed save, the creature is knocked prone.

This spell can have additional effects depending on the terrain in the area, as determined by the DM.

Fissures. Fissures open throughout the spell''s area at the start of your next turn after you cast the spell. A total of 1d6 such fissures open in locations chosen by the DM. Each is 1d10 × 10 feet deep, 10 feet wide, and extends from one edge of the spell''s area to the opposite side. A creature standing on a spot where a fissure opens must succeed on a Dexterity saving throw or fall in. A creature that successfully saves moves with the fissure''s edge as it opens.

A fissure that opens beneath a structure causes it to automatically collapse (see below).

Structures. The tremor deals 50 bludgeoning damage to any structure in contact with the ground in the area when you cast the spell and at the start of each of your turns until the spell ends. If a structure drops to 0 hit points, it collapses and potentially damages nearby creatures. A creature within half the distance of a structure''s height must make a Dexterity saving throw. On a failed save, the creature takes 5d6 bludgeoning damage, is knocked prone, and is buried in the rubble, requiring a DC 20 Strength (Athletics) check as an action to escape. The DM can adjust the DC higher or lower, depending on the nature of the rubble. On a successful save, the creature takes half as much damage and doesn''t fall prone or become buried.',NULL,'1 minute','1 action','Earthquake',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),8,'500 feet','A pinch of dirt, a piece of rock, and a lump of clay',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A beam of crackling energy streaks toward a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 force damage.','The spell creates more than one beam when you reach higher levels: two beams at 5th level, three beams at 11th level, and four beams at 17th level. You can direct the beams at the same target or at different ones. Make a separate attack roll for each beam.','Instantaneous','1 action','Eldritch Blast',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),0,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You touch a creature and bestow upon it a magical enhancement. Choose one of the following effects; the target gains that effect until the spell ends.

Bear''s Endurance. The target has advantage on Constitution checks. It also gains 2d6 temporary hit points, which are lost when the spell ends.

Bull''s Strength. The target has advantage on Strength checks, and his or her carrying capacity doubles.

Cat''s Grace. The target has advantage on Dexterity checks. It also doesn''t take damage from falling 20 feet or less if it isn''t incapacitated.

Eagle''s Splendor. The target has advantage on Charisma checks.

Fox''s Cunning. The target has advantage on Intelligence checks.

Owl''s Wisdom. The target has advantage on Wisdom checks.','When you cast this spell using a spell slot of 3rd level or higher, you can target one additional creature for each slot level above 2nd.','1 hour','1 action','Enhance Ability',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'Touch','Fur or a feather from a beast',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You cause a creature or an object you can see within range to grow larger or smaller for the duration. Choose either a creature or an object that is neither worn nor carried. If the target is unwilling, it can make a Constitution saving throw. On a success, the spell has no effect.

If the target is a creature, everything it is wearing and carrying changes size with it. Any item dropped by an affected creature returns to normal size at once.

Enlarge. The target''s size doubles in all dimensions, and its weight is multiplied by eight. This growth increases its size by one category—from Medium to Large, for example. If there isn''t enough room for the target to double its size, the creature or object attains the maximum possible size in the space available. Until the spell ends, the target also has advantage on Strength checks and Strength saving throws. The target''s weapons also grow to match its new size. While these weapons are enlarged, the target''s attacks with them deal 1d4 extra damage.

Reduce. The target''s size is halved in all dimensions, and its weight is reduced to one-eighth of normal. This reduction decreases its size by one category—from Medium to Small, for example. Until the spell ends, the target also has disadvantage on Strength checks and Strength saving throws. The target''s weapons also shrink to match its new size. While these weapons are reduced, the target''s attacks with them deal 1d4 less damage (this can''t reduce the damage below 1).',NULL,'1 minute','1 action','Enlarge/Reduce',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'30 feet','A pinch of powdered iron',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Grasping weeds and vines sprout from the ground in a 20-foot square starting from a point within range. For the duration, these plants turn the ground in the area into difficult terrain.

A creature in the area when you cast the spell must succeed on a Strength saving throw or be restrained by the entangling plants until the spell ends. A creature restrained by the plants can use its action to make a Strength check against your spell save DC. On a success, it frees itself.

When the spell ends, the conjured plants wilt away.',NULL,'1 minute','1 action','Entangle',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),1,'90 feet (20 feet)',NULL,NULL,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You weave a distracting string of words, causing creatures of your choice that you can see within range and that can hear you to make a Wisdom saving throw. Any creature that can''t be charmed succeeds on this saving throw automatically, and if you or your companions are fighting a creature, it has advantage on the save. On a failed save, the target has disadvantage on Wisdom (Perception) checks made to perceive any creature other than you until the spell ends or until the target can no longer hear you. The spell ends if you are incapacitated or can no longer speak.',NULL,'1 minute','1 action','Enthrall',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),2,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You step into the border regions of the Ethereal Plane, in the area where it overlaps with your current plane. You remain in the Border Ethereal for the duration or until you use your action to dismiss the spell. During this time, you can move in any direction. If you move up or down, every foot of movement costs an extra foot. You can see and hear the plane you originated from, but everything there looks gray, and you can''t see anything more than 60 feet away.

While on the Ethereal Plane, you can only affect and be affected by other creatures on that plane. Creatures that aren''t on the Ethereal Plane can''t perceive you and can''t interact with you, unless a special ability or magic has given them the ability to do so.

You ignore all objects and effects that aren''t on the Ethereal Plane, allowing you to move through objects you perceive on the plane you originated from.

When the spell ends, you immediately return to the plane you originated from in the spot you currently occupy. If you occupy the same spot as a solid object or creature when this happens, you are immediately shunted to the nearest unoccupied space that you can occupy and take force damage equal to twice the number of feet you are moved.

This spell has no effect if you cast it while you are on the Ethereal Plane or a plane that doesn''t border it, such as one of the Outer Planes.','When you cast this spell using a spell slot of 8th level or higher, you can target up to three willing creatures (including you) for each slot level above 7th. The creatures must be within 10 feet of you when you cast the spell.','8 hours','1 action','Etherealness',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),7,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'This spell allows you to move at an incredible pace. When you cast this spell, and then as a bonus action on each of your turns until the spell ends, you can take the Dash action.',NULL,'10 minutes','1 bonus action','Expeditious Retreat',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),1,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'For the spell''s duration, your eyes become an inky void imbued with dread power. One creature of your choice within 60 feet of you that you can see must succeed on a Wisdom saving throw or be affected by one of the following effects of your choice for the duration. On each of your turns until the spell ends, you can use your action to target another creature but can''t target a creature again if it has succeeded on a saving throw against this casting of eyebite.

Asleep. The target falls unconscious. It wakes up if it takes any damage or if another creature uses its action to shake the sleeper awake.

Panicked. The target is frightened of you. On each of its turns, the frightened creature must take the Dash action and move away from you by the safest and shortest available route, unless there is nowhere to move. If the target moves to a place at least 60 feet away from you where it can no longer see you, this effect ends.

Sickened. The target has disadvantage on attack rolls and ability checks. At the end of each of its turns, it can make another Wisdom saving throw. If it succeeds, the effect ends.',NULL,'1 minute','1 action','Eyebite',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),6,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You convert raw materials into products of the same material. For example, you can fabricate a wooden bridge from a clump of trees, a rope from a patch of hemp, and clothes from flax or wool.

Choose raw materials that you can see within range. You can fabricate a Large or smaller object (contained within a 10-foot cube, or eight connected 5-foot cubes), given a sufficient quantity of raw material. If you are working with metal, stone, or another mineral substance, however, the fabricated object can be no larger than Medium (contained within a single 5-foot cube). The quality of objects made by the spell is commensurate with the quality of the raw materials.

Creatures or magic items can''t be created or transmuted by this spell. You also can''t use it to create items that ordinarily require a high degree of craftsmanship, such as jewelry, weapons, glass, or armor, unless you have proficiency with the type of artisan''s tools used to craft such objects.',NULL,'Instantaneous','10 minutes','Fabricate',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),4,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Each object in a 20-foot cube within range is outlined in blue, green, or violet light (your choice). Any creature in the area when the spell is cast is also outlined in light if it fails a Dexterity saving throw. For the duration, objects and affected creatures shed dim light in a 10-foot radius.

Any attack roll against an affected creature or object has advantage if the attacker can see it, and the affected creature or object can''t benefit from being invisible.',NULL,'1 minute','1 action','Faerie Fire',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),1,'60 feet (20 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Bolstering yourself with a necromantic facsimile of life, you gain 1d4 + 4 temporary hit points for the duration.','When you cast this spell using a spell slot of 2nd level or higher, you gain 5 additional temporary hit points for each slot level above 1st.','1 hour','1 action','False Life',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),1,'Self','A small amount of alcohol or distilled spirits',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You project a phantasmal image of a creature''s worst fears. Each creature in a 30-foot cone must succeed on a Wisdom saving throw or drop whatever it is holding and become frightened for the duration.

While frightened by this spell, a creature must take the Dash action and move away from you by the safest available route on each of its turns, unless there is nowhere to move. If the creature ends its turn in a location where it doesn''t have line of sight to you, the creature can make a Wisdom saving throw. On a successful save, the spell ends for that creature.',NULL,'1 minute','1 action','Fear',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),3,'Self (30 feet)','A white feather or the heart of a hen',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Choose up to five falling creatures within range. A falling creature''s rate of descent slows to 60 feet per round until the spell ends. If the creature lands before the spell ends, it takes no falling damage and can land on its feet, and the spell ends for that creature.',NULL,'1 minute','1 reaction','Feather Fall',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),1,'60 feet','A small feather or piece of down',0,'which you take when you or a creature within 60 feet of you falls');
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You blast the mind of a creature that you can see within range, attempting to shatter its intellect and personality. The target takes 4d6 psychic damage and must make an Intelligence saving throw.

On a failed save, the creature''s Intelligence and Charisma scores become 1. The creature can''t cast spells, activate magic items, understand language, or communicate in any intelligible way. The creature can, however, identify its friends, follow them, and even protect them.

At the end of every 30 days, the creature can repeat its saving throw against this spell. If it succeeds on its saving throw, the spell ends.

The spell can also be ended by greater restoration, heal, or wish.',NULL,'Instantaneous','1 action','Feeblemind',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),8,'150 feet','A handful of clay, crystal, glass, or mineral spheres',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You gain the service of a familiar, a spirit that takes an animal form you choose: bat, cat, crab, frog (toad), hawk, lizard, octopus, owl, poisonous snake, fish (quipper), rat, raven, sea horse, spider, or weasel. Appearing in an unoccupied space within range, the familiar has the statistics of the chosen form, though it is a celestial, fey, or fiend (your choice) instead of a beast.

Your familiar acts independently of you, but it always obeys your commands. In combat, it rolls its own initiative and acts on its own turn. A familiar can''t attack, but it can take other actions as normal.

When the familiar drops to 0 hit points, it disappears, leaving behind no physical form. It reappears after you cast this spell again

While your familiar is within 100 feet of you, you can communicate with it telepathically. Additionally, as an action, you can see through your familiar''s eyes and hear what it hears until the start of your next turn, gaining the benefits of any special senses that the familiar has. During this time, you are deaf and blind with regard to your own senses.

As an action, you can temporarily dismiss your familiar. It disappears into a pocket dimension where it awaits your summons. Alternatively, you can dismiss it forever. As an action while it is temporarily dismissed, you can cause it to reappear in any unoccupied space within 30 feet of you.

You can''t have more than one familiar at a time. If you cast this spell while you already have a familiar, you instead cause it to adopt a new form. Choose one of the forms from the above list. Your familiar transforms into the chosen creature.

Finally, when you cast a spell with a range of touch, your familiar can deliver the spell as if it had cast the spell. Your familiar must be within 100 feet of you, and it must use its reaction to deliver the spell when you cast it. If the spell requires an attack roll, you use your attack modifier for the roll.',NULL,'Instantaneous','1 hour','Find Familiar',1,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),1,'10 feet','10 gp worth of charcoal, incense, and herbs that must be consumed by fire in a brass brazier',10,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You summon a spirit that assumes the form of an unusually intelligent, strong, and loyal steed, creating a long-lasting bond with it. Appearing in an unoccupied space within range, the steed takes on a form that you choose: a warhorse, a pony, a camel, an elk, or a mastiff. (Your DM might allow other animals to be summoned as steeds.) The steed has the statistics of the chosen form, though it is a celestial, fey, or fiend (your choice) instead of its normal type. Additionally, if your steed has an Intelligence of 5 or less, its Intelligence becomes 6, and it gains the ability to understand one language of your choice that you speak.

Your steed serves you as a mount, both in combat and out, and you have an instinctive bond with it that allows you to fight as a seamless unit. While mounted on your steed, you can make any spell you cast that targets only you also target your steed.

When the steed drops to 0 hit points, it disappears, leaving behind no physical form. You can also dismiss your steed at any time as an action, causing it to disappear. In either case, casting this spell again summons the same steed, restored to its hit point maximum.

While your steed is within 1 mile of you, you can communicate with each other telepathically.

You can''t have more than one steed bonded by this spell at a time. As an action, you can release the steed from its bond at any time, causing it to disappear.',NULL,'Instantaneous','10 minutes','Find Steed',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),2,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'This spell allows you to find the shortest, most direct physical route to a specific fixed location that you are familiar with on the same plane of existence. If you name a destination on another plane of existence, a destination that moves (such as a mobile fortress), or a destination that isn''t specific (such as "a green dragon''s lair"), the spell fails.

For the duration, as long as you are on the same plane of existence as the destination, you know how far it is and in what direction it lies. While you are traveling there, whenever you are presented with a choice of paths along the way, you automatically determine which path is the shortest and most direct route (but not necessarily the safest route) to the destination.',NULL,'1 day','1 minute','Find the Path',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),6,'Self','A set of divinatory tools--such as bones, ivory sticks, cards, teeth, or carved runes--worth 100 gp and an object from the location you wish to find',100,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You sense the presence of any trap within range that is within line of sight. A trap, for the purpose of this spell, includes anything that would inflict a sudden or unexpected effect you consider harmful or undesirable, which was specifically intended as such by its creator. Thus, the spell would sense an area affected by the alarm spell, a glyph of warding, or a mechanical pit trap, but it would not reveal a natural weakness in the floor, an unstable ceiling, or a hidden sinkhole.

This spell merely reveals that a trap is present. You don''t learn the location of each trap, but you do learn the general nature of the danger posed by a trap you sense.',NULL,'Instantaneous','1 action','Find Traps',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),2,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You send negative energy coursing through a creature that you can see within range, causing it searing pain. The target must make a Constitution saving throw. It takes 7d8 + 30 necrotic damage on a failed save, or half as much damage on a successful one.

A humanoid killed by this spell rises at the start of your next turn as a zombie that is permanently under your command, following your verbal orders to the best of its ability.',NULL,'Instantaneous','1 action','Finger of Death',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),7,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A bright streak flashes from your pointing finger to a point you choose within range and then blossoms with a low roar into an explosion of flame. Each creature in a 20-foot-radius sphere centered on that point must make a Dexterity saving throw. A target takes 8d6 fire damage on a failed save, or half as much damage on a successful one.

The fire spreads around corners. It ignites flammable objects in the area that aren''t being worn or carried.','When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d6 for each slot level above 3rd.','Instantaneous','1 action','Fireball',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),3,'150 feet (20 feet)','A tiny ball of bat guano and sulfur',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You hurl a mote of fire at a creature or object within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 fire damage. A flammable object hit by this spell ignites if it isn''t being worn or carried.','This spell''s damage increases by 1d10 when you reach 5th level (2d10), 11th level (3d10), and 17th level (4d10).','Instantaneous','1 action','Fire Bolt',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),0,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Thin and wispy flames wreathe your body for the duration, shedding bright light in a 10-foot radius and dim light for an additional 10 feet. You can end the spell early by using an action to dismiss it.

The flames provide you with a warm shield or a chill shield, as you choose. The warm shield grants you resistance to cold damage, and the chill shield grants you resistance to fire damage.

In addition, whenever a creature within 5 feet of you hits you with a melee attack, the shield erupts with flame. The attacker takes 2d8 fire damage from a warm shield, or 2d8 cold damage from a cold shield.',NULL,'10 minutes','1 action','Fire Shield',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),4,'Self','A bit of phosphorus or a firefly',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A storm made up of sheets of roaring flame appears in a location you choose within range. The area of the storm consists of up to ten 10-foot cubes, which you can arrange as you wish. Each cube must have at least one face adjacent to the face of another cube. Each creature in the area must make a Dexterity saving throw. It takes 7d10 fire damage on a failed save, or half as much damage on a successful one.

The fire damages objects in the area and ignites flammable objects that aren''t being worn or carried. If you choose, plant life in the area is unaffected by this spell.',NULL,'Instantaneous','1 action','Fire Storm',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),7,'150 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You evoke a fiery blade in your free hand. The blade is similar in size and shape to a scimitar, and it lasts for the duration. If you let go of the blade, it disappears, but you can evoke the blade again as a bonus action.

You can use your action to make a melee spell attack with the fiery blade. On a hit, the target takes 3d6 fire damage.

The flaming blade sheds bright light in a 10-foot radius and dim light for an additional 10 feet.','When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d6 for every two slot levels above 2nd.','10 minutes','1 bonus action','Flame Blade',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),2,'Self','Leaf of sumac',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A vertical column of divine fire roars down from the heavens in a location you specify. Each creature in a 10-foot-radius, 40-foot-high cylinder centered on a point within range must make a Dexterity saving throw. A creature takes 4d6 fire damage and 4d6 radiant damage on a failed save, or half as much damage on a successful one.','When you cast this spell using a spell slot of 6th level or higher, the fire damage or the radiant damage (your choice) increases by 1d6 for each slot level above 5th.','Instantaneous','1 action','Flame Strike',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),5,'60 feet (10 feet)','Pinch of sulfur',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A 5-foot-diameter sphere of fire appears in an unoccupied space of your choice within range and lasts for the duration. Any creature that ends its turn within 5 feet of the sphere must make a Dexterity saving throw. The creature takes 2d6 fire damage on a failed save, or half as much damage on a successful one.

As a bonus action, you can move the sphere up to 30 feet. If you ram the sphere into a creature, that creature must make the saving throw against the sphere''s damage, and the sphere stops moving this turn.

When you move the sphere, you can direct it over barriers up to 5 feet tall and jump it across pits up to 10 feet wide. The sphere ignites flammable objects not being worn or carried, and it sheds bright light in a 20-foot radius and dim light for an additional 20 feet.','When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d6 for each slot level above 2nd.','1 minute','1 action','Flaming Sphere',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),2,'60 feet (5 feet)','A bit of tallow, a pinch of brimstone, and a dusting of powdered iron',0,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You attempt to turn one creature that you can see within range into stone. If the target''s body is made of flesh, the creature must make a Constitution saving throw. On a failed save, it is restrained as its flesh begins to harden. On a successful save, the creature isn''t affected.

A creature restrained by this spell must make another Constitution saving throw at the end of each of its turns. If it successfully saves against this spell three times, the spell ends. If it fails its saves three times, it is turned to stone and subjected to the petrified condition for the duration. The successes and failures don''t need to be consecutive; keep track of both until the target collects three of a kind.

If the creature is physically broken while petrified, it suffers from similar deformities if it reverts to its original state.

If you maintain your concentration on this spell for the entire possible duration, the creature is turned to stone until the effect is removed.',NULL,'1 minute','1 action','Flesh to Stone',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),6,'60 feet','A pinch of lime, water, and earth',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You touch a willing creature. The target gains a flying speed of 60 feet for the duration. When the spell ends, the target falls if it is still aloft, unless it can stop the fall.','When you cast this spell using a spell slot of 4th level or higher, you can target one additional creature for each slot level above 3rd.','10 minutes','1 action','Fly',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),3,'Touch','A wing feather from any bird',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create a 20-foot-radius sphere of fog centered on a point within range. The sphere spreads around corners, and its area is heavily obscured. It lasts for the duration or until a wind of moderate or greater speed (at least 10 miles per hour) disperses it.','When you cast this spell using a spell slot of 2nd level or higher, the radius of the fog increases by 20 feet for each slot level above 1st.','1 hour','1 action','Fog Cloud',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),1,'120 feet (20 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create a ward against magical travel that protects up to 40,000 square feet of floor space to a height of 30 feet above the floor. For the duration, creatures can''t teleport into the area or use portals, such as those created by the gate spell, to enter the area. The spell proofs the area against planar travel, and therefore prevents creatures from accessing the area by way of the Astral Plane, Ethereal Plane, Feywild, Shadowfell, or the plane shift spell.

In addition, the spell damages types of creatures that you choose when you cast it. Choose one or more of the following: celestials, elementals, fey, fiends, and undead. When a chosen creature enters the spell''s area for the first time on a turn or starts its turn there, the creature takes 5d10 radiant or necrotic damage (your choice when you cast this spell).

When you cast this spell, you can designate a password. A creature that speaks the password as it enters the area takes no damage from the spell.

The spell''s area can''t overlap with the area of another forbiddance spell. If you cast forbiddance every day for 30 days in the same location, the spell lasts until it is dispelled, and the material components are consumed on the last casting.',NULL,'1 day','10 minutes','Forbiddance',1,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),6,'Touch (40000 feet)','A sprinkling of holy water, rare incense, and powdered ruby worth at least 1,000 gp',1000,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'An immobile, invisible, cube-shaped prison composed of magical force springs into existence around an area you choose within range. The prison can be a cage or a solid box, as you choose.

A prison in the shape of a cage can be up to 20 feet on a side and is made from 1/2-inch diameter bars spaced 1/2 inch apart.

A prison in the shape of a box can be up to 10 feet on a side, creating a solid barrier that prevents any matter from passing through it and blocking any spells cast into or out from the area.

When you cast the spell, any creature that is completely inside the cage''s area is trapped. Creatures only partially within the area, or those too large to fit inside the area, are pushed away from the center of the area until they are completely outside the area.

A creature inside the cage can''t leave it by nonmagical means. If the creature tries to use teleportation or interplanar travel to leave the cage, it must first make a Charisma saving throw. On a success, the creature can use that magic to exit the cage. On a failure, the creature can''t exit the cage and wastes the use of the spell or effect. The cage also extends into the Ethereal Plane, blocking ethereal travel.

This spell can''t be dispelled by dispel magic.',NULL,'1 hour','1 action','Forcecage',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),7,'100 feet','Ruby dust worth 1,500 gp',1500,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a willing creature and bestow a limited ability to see into the immediate future. For the duration, the target can''t be surprised and has advantage on attack rolls, ability checks, and saving throws. Additionally, other creatures have disadvantage on attack rolls against the target for the duration.

This spell immediately ends if you cast it again before its duration ends.',NULL,'8 hours','1 minute','Foresight',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),9,'Touch','A hummingbird feather',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a willing creature. For the duration, the target''s movement is unaffected by difficult terrain, and spells and other magical effects can neither reduce the target''s speed nor cause the target to be paralyzed or restrained.

The target can also spend 5 feet of movement to automatically escape from nonmagical restraints, such as manacles or a creature that has it grappled. Finally, being underwater imposes no penalties on the target''s movement or attacks.',NULL,'1 hour','1 action','Freedom of Movement',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),4,'Touch','A leather strap, bound around the arm or a similar appendage',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You transform a willing creature you touch, along with everything it''s wearing and carrying, into a misty cloud for the duration. The spell ends if the creature drops to 0 hit points. An incorporeal creature isn''t affected.

While in this form, the target''s only method of movement is a flying speed of 10 feet. The target can enter and occupy the space of another creature. The target has resistance to nonmagical damage, and it has advantage on Strength, Dexterity, and Constitution saving throws. The target can pass through small holes, narrow openings, and even mere cracks, though it treats liquids as though they were solid surfaces. The target can''t fall and remains hovering in the air even when stunned or otherwise incapacitated.

While in the form of a misty cloud, the target can''t talk or manipulate objects, and any objects it was carrying or holding can''t be dropped, used, or otherwise interacted with. The target can''t attack or cast spells.',NULL,'1 hour','1 action','Gaseous Form',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),3,'Touch','A bit of gauze and a wisp of smoke',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You conjure a portal linking an unoccupied space you can see within range to a precise location on a different plane of existence. The portal is a circular opening, which you can make 5 to 20 feet in diameter. You can orient the portal in any direction you choose. The portal lasts for the duration.

The portal has a front and a back on each plane where it appears. Travel through the portal is possible only by moving through its front. Anything that does so is instantly transported to the other plane, appearing in the unoccupied space nearest to the portal.

Deities and other planar rulers can prevent portals created by this spell from opening in their presence or anywhere within their domains.

When you cast this spell, you can speak the name of a specific creature (a pseudonym, title, or nickname doesn''t work). If that creature is on a plane other than the one you are on, the portal opens in the named creature''s immediate vicinity and draws the creature through it to the nearest unoccupied space on your side of the portal. You gain no special power over the creature, and it is free to act as the DM deems appropriate. It might leave, attack you, or help you.',NULL,'1 minute','1 action','Gate',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),9,'60 feet','A diamond worth at least 5,000 gp',5000,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You place a magical command on a creature that you can see within range, forcing it to carry out some service or refrain from some action or course of activity as you decide. If the creature can understand you, it must succeed on a Wisdom saving throw or become charmed by you for the duration. While the creature is charmed by you, it takes 5d10 psychic damage each time it acts in a manner directly counter to your instructions, but no more than once each day. A creature that can''t understand you is unaffected by the spell.

You can issue any command you choose, short of an activity that would result in certain death. Should you issue a suicidal command, the spell ends.

You can end the spell early by using an action to dismiss it. A remove curse, greater restoration, or wish spell also ends it.','When you cast this spell using a spell slot of 7th or 8th level, the duration is 1 year. When you cast this spell using a spell slot of 9th level, the spell lasts until it is ended by one of the spells mentioned above.','30 days','1 minute','Geas',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),5,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a corpse or other remains. For the duration, the target is protected from decay and can''t become undead.

The spell also effectively extends the time limit on raising the target from the dead, since days spent under the influence of this spell don''t count against the time limit of spells such as raise dead.',NULL,'10 days','1 action','Gentle Repose',1,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),2,'Touch','A pinch of salt and one copper piece placed on each of the corpse''s eyes, which must remain there for the duration',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You transform up to ten centipedes, three spiders, five wasps, or one scorpion within range into giant versions of their natural forms for the duration. A centipede becomes a giant centipede, a spider becomes a giant spider, a wasp becomes a giant wasp, and a scorpion becomes a giant scorpion.

Each creature obeys your verbal commands, and in combat, they act on your turn each round. The DM has the statistics for these creatures and resolves their actions and movement.

A creature remains in its giant size for the duration, until it drops to 0 hit points, or until you use an action to dismiss the effect on it.

The DM might allow you to choose different targets. For example, if you transform a bee, its giant version might have the same statistics as a giant wasp.',NULL,'10 minutes','1 action','Giant Insect',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),4,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Until the spell ends, when you make a Charisma check, you can replace the number you roll with a 15. Additionally, no matter what you say, magic that would determine if you are telling the truth indicates that you are being truthful.',NULL,'1 hour','1 action','Glibness',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),8,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'An immobile, faintly shimmering barrier springs into existence in a 10-foot radius around you and remains for the duration.

Any spell of 5th level or lower cast from outside the barrier can''t affect creatures or objects within it, even if the spell is cast using a higher level spell slot. Such a spell can target creatures and objects within the barrier, but the spell has no effect on them. Similarly, the area within the barrier is excluded from the areas affected by such spells.','When you cast this spell using a spell slot of 7th level or higher, the barrier blocks spells of one level higher for each slot level above 6th.','1 minute','1 action','Globe of Invulnerability',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),6,'Self (10 feet)','A glass or crystal bead that shatters when the spell ends',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'When you cast this spell, you inscribe a glyph that later unleashes a magical effect. You inscribe it either on a surface (such as a table or a section of floor or wall) or within an object that can be closed (such as a book, a scroll, or a treasure chest) to conceal the glyph. The glyph can cover an area no larger than 10 feet in diameter. If the surface or object is moved more than 10 feet from where you cast this spell, the glyph is broken, and the spell ends without being triggered.

The glyph is nearly invisible and requires a successful Intelligence (Investigation) check against your spell save DC to be found.

You decide what triggers the glyph when you cast the spell. For glyphs inscribed on a surface, the most typical triggers include touching or standing on the glyph, removing another object covering the glyph, approaching within a certain distance of the glyph, or manipulating the object on which the glyph is inscribed. For glyphs inscribed within an object, the most common triggers include opening that object, approaching within a certain distance of the object, or seeing or reading the glyph. Once a glyph is triggered, this spell ends.

You can further refine the trigger so the spell activates only under certain circumstances or according to physical characteristics (such as height or weight), creature kind (for example, the ward could be set to affect aberrations or drow), or alignment. You can also set conditions for creatures that don''t trigger the glyph, such as those who say a certain password.

When you inscribe the glyph, choose explosive runes or a spell glyph.

Explosive Runes. When triggered, the glyph erupts with magical energy in a 20-foot-radius sphere centered on the glyph. The sphere spreads around corners. Each creature in the area must make a Dexterity saving throw. A creature takes 5d8 acid, cold, fire, lightning, or thunder damage on a failed saving throw (your choice when you create the glyph), or half as much damage on a successful one.

Spell Glyph. You can store a prepared spell of 3rd level or lower in the glyph by casting it as part of creating the glyph. The spell must target a single creature or an area. The spell being stored has no immediate effect when cast in this way. When the glyph is triggered, the stored spell is cast. If the spell has a target, it targets the creature that triggered the glyph. If the spell affects an area, the area is centered on that creature. If the spell summons hostile creatures or creates harmful objects or traps, they appear as close as possible to the intruder and attack it. If the spell requires concentration, it lasts until the end of its full duration.','When you cast this spell using a spell slot of 4th level or higher, the damage of an explosive runes glyph increases by 1d8 for each slot level above 3rd. If you create a spell glyph, you can store any spell of up to the same level as the slot you use for the glyph of warding.','Until Dispelled','1 hour','Glyph of Warding',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),3,'Touch','Incense and powdered diamond worth at least 200 gp, which the spell consumes',200,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Up to ten berries appear in your hand and are infused with magic for the duration. A creature can use its action to eat one berry. Eating a berry restores 1 hit point, and the berry provides enough nourishment to sustain a creature for one day.

The berries lose their potency if they have not been consumed within 24 hours of the casting of this spell.',NULL,'Instantaneous','1 action','Goodberry',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),1,'Touch','A sprig of mistletoe',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Slick grease covers the ground in a 10-foot square centered on a point within range and turns it into difficult terrain for the duration.

When the grease appears, each creature standing in its area must succeed on a Dexterity saving throw or fall prone. A creature that enters the area or ends its turn there must also succeed on a Dexterity saving throw or fall prone.',NULL,'1 minute','1 action','Grease',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),1,'60 feet (10 feet)','A bit of pork rind or butter',0,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You or a creature you touch becomes invisible until the spell ends. Anything the target is wearing or carrying is invisible as long as it is on the target''s person.',NULL,'1 minute','1 action','Greater Invisibility',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),4,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You imbue a creature you touch with positive energy to undo a debilitating effect. You can reduce the target''s exhaustion level by one, or end one of the following effects on the target:

- One effect that charmed or petrified the target
- One curse, including the target''s attunement to a cursed magic item
- Any reduction to one of the target''s ability scores
- One effect reducing the target''s hit point maximum',NULL,'Instantaneous','1 action','Greater Restoration',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),5,'Touch','Diamond dust worth at least 100 gp, which the spell consumes',100,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A Large spectral guardian appears and hovers for the duration in an unoccupied space of your choice that you can see within range. The guardian occupies that space and is indistinct except for a gleaming sword and shield emblazoned with the symbol of your deity.

Any creature hostile to you that moves to a space within 10 feet of the guardian for the first time on a turn must succeed on a Dexterity saving throw. The creature takes 20 radiant damage on a failed save, or half as much damage on a successful one. The guardian vanishes when it has dealt a total of 60 damage.',NULL,'8 hours','1 action','Guardian of Faith',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),4,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create a ward that protects up to 2,500 square feet of floor space (an area 50 feet square, or one hundred 5-foot squares or twenty-five 10-foot squares). The warded area can be up to 20 feet tall, and shaped as you desire. You can ward several stories of a stronghold by dividing the area among them, as long as you can walk into each contiguous area while you are casting the spell.

When you cast this spell, you can specify individuals that are unaffected by any or all of the effects that you choose. You can also specify a password that, when spoken aloud, makes the speaker immune to these effects.

Guards and wards creates the following effects within the warded area.

Corridors. Fog fills all the warded corridors, making them heavily obscured. In addition, at each intersection or branching passage offering a choice of direction, there is a 50 percent chance that a creature other than you will believe it is going in the opposite direction from the one it chooses.

Doors. All doors in the warded area are magically locked, as if sealed by an arcane lock spell. In addition, you can cover up to ten doors with an illusion (equivalent to the illusory object function of the minor illusion spell) to make them appear as plain sections of wall.

Stairs. Webs fill all stairs in the warded area from top to bottom, as the web spell. These strands regrow in 10 minutes if they are burned or torn away while guards and wards lasts.

Other Spell Effect. You can place your choice of one of the following magical effects within the warded area of the stronghold.

- Place dancing lights in four corridors. You can designate a simple program that the lights repeat as long as guards and wards lasts.
- Place magic mouth in two locations.
- Place stinking cloud in two locations. The vapors appear in the places you designate; they return within 10 minutes if dispersed by wind while guards and wards lasts.
- Place a constant gust of wind in one corridor or room.
- Place a suggestion in one location. You select an area of up to 5 feet square, and any creature that enters or passes through the area receives the suggestion mentally.

The whole warded area radiates magic. A dispel magic cast on a specific effect, if successful, removes only that effect.

You can create a permanently guarded and warded structure by casting this spell there every day for one year.',NULL,'24 hours','10 minutes','Guards and Wards',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),6,'Touch (2500 feet)','Burning incense, a small measure of brimstone and oil, a knotted string, a small amount of monster blood, and a small silver rod worth at least 10 gp',10,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one ability check of its choice. It can roll the die before or after making the ability check. The spell then ends.',NULL,'1 minute','1 action','Guidance',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),0,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A flash of light streaks toward a creature of your choice within range. Make a ranged spell attack against the target. On a hit, the target takes 4d6 radiant damage, and the next attack roll made against this target before the end of your next turn has advantage, thanks to the mystical dim light glittering on the target until then.','When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d6 for each slot level above 1st.','1 round','1 action','Guiding Bolt',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),1,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A line of strong wind 60 feet long and 10 feet wide blasts from you in a direction you choose for the spell''s duration. Each creature that starts its turn in the line must succeed on a Strength saving throw or be pushed 15 feet away from you in a direction following the line.

Any creature in the line must spend 2 feet of movement for every 1 foot it moves when moving closer to you.

The gust disperses gas or vapor, and it extinguishes candles, torches, and similar unprotected flames in the area. It causes protected flames, such as those of lanterns, to dance wildly and has a 50 percent chance to extinguish them.

As a bonus action on each of your turns before the spell ends, you can change the direction in which the line blasts from you.',NULL,'1 minute','1 action','Gust of Wind',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),2,'Self','A legume seed',0,NULL);

COMMIT;

BEGIN TRANSACTION;

INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Aid'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Messenger'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Shapes'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Dead'),(SELECT rowid FROM target WHERE type LIKE 'Corpse'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antilife Shell'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antimagic Field'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Eye'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Lock'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Augury'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Awaken'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bane'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Barkskin'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Barkskin'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Beacon of Hope'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Beacon of Hope'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blade Barrier'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bless'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bless'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blink'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blur'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Branding Smite'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Call Lightning'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Calm Emotions'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clone'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clone'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune with Nature'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Compulsion'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Animals'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Celestial'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Elemental'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Fey'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Minor Elementals'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Woodland Beings'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contact Other Plane'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contingency'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Continual Flame'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Weather'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Counterspell'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Food and Water'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create or Destroy Water'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create or Destroy Water'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Undead'),(SELECT rowid FROM target WHERE type LIKE 'Corpse'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkness'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Death Ward'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Demiplane'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Evil and Good'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disguise Self'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divination'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Favor'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Word'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Beast'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Druidcraft'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Druidcraft'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eldritch Blast'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Entangle'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enthrall'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Expeditious Retreat'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fabricate'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'False Life'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Familiar'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Steed'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find the Path'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Traps'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Traps'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Shield'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Blade'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forbiddance'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gate'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gentle Repose'),(SELECT rowid FROM target WHERE type LIKE 'Corpse'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Giant Insect'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glibness'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Globe of Invulnerability'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Goodberry'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guardian of Faith'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guidance'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guidance'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guiding Bolt'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));

INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bane'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blade Barrier'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Call Lightning'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Calm Emotions'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Compulsion'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contact Other Plane'),(SELECT rowid FROM ability WHERE shortname LIKE 'INT'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM ability WHERE shortname LIKE 'STR'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Word'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Beast'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Entangle'),(SELECT rowid FROM ability WHERE shortname LIKE 'STR'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enthrall'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM ability WHERE shortname LIKE 'INT'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guardian of Faith'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM ability WHERE shortname LIKE 'STR'));

INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Weapon'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Weapon'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Branding Smite'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Weapon'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Branding Smite'),(SELECT rowid FROM attack_type WHERE type LIKE 'Ranged Weapon'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM attack_type WHERE type LIKE 'Ranged Spell'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Spell'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Spell'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Favor'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Weapon'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Favor'),(SELECT rowid FROM attack_type WHERE type LIKE 'Ranged Weapon'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eldritch Blast'),(SELECT rowid FROM attack_type WHERE type LIKE 'Ranged Spell'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM attack_type WHERE type LIKE 'Ranged Spell'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Blade'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Spell'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guiding Bolt'),(SELECT rowid FROM attack_type WHERE type LIKE 'Ranged Spell'));

INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM damage_type WHERE type LIKE 'Acid'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM damage_type WHERE type LIKE 'Bludgeoning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM damage_type WHERE type LIKE 'Piercing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM damage_type WHERE type LIKE 'Slashing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM damage_type WHERE type LIKE 'Bludgeoning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM damage_type WHERE type LIKE 'Piercing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM damage_type WHERE type LIKE 'Slashing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM damage_type WHERE type LIKE 'Necrotic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blade Barrier'),(SELECT rowid FROM damage_type WHERE type LIKE 'Slashing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM damage_type WHERE type LIKE 'Necrotic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Branding Smite'),(SELECT rowid FROM damage_type WHERE type LIKE 'Radiant'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Call Lightning'),(SELECT rowid FROM damage_type WHERE type LIKE 'Lightning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM damage_type WHERE type LIKE 'Lightning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM damage_type WHERE type LIKE 'Necrotic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM damage_type WHERE type LIKE 'Necrotic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM damage_type WHERE type LIKE 'Poison'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM damage_type WHERE type LIKE 'Cold'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contact Other Plane'),(SELECT rowid FROM damage_type WHERE type LIKE 'Psychic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM damage_type WHERE type LIKE 'Bludgeoning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM damage_type WHERE type LIKE 'Healing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM damage_type WHERE type LIKE 'Force'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM damage_type WHERE type LIKE 'Force'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Favor'),(SELECT rowid FROM damage_type WHERE type LIKE 'Radiant'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM damage_type WHERE type LIKE 'Psychic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM damage_type WHERE type LIKE 'Bludgeoning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eldritch Blast'),(SELECT rowid FROM damage_type WHERE type LIKE 'Force'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM damage_type WHERE type LIKE 'Force'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM damage_type WHERE type LIKE 'Psychic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM damage_type WHERE type LIKE 'Necrotic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Shield'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Shield'),(SELECT rowid FROM damage_type WHERE type LIKE 'Cold'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Blade'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM damage_type WHERE type LIKE 'Radiant'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forbiddance'),(SELECT rowid FROM damage_type WHERE type LIKE 'Necrotic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forbiddance'),(SELECT rowid FROM damage_type WHERE type LIKE 'Radiant'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM damage_type WHERE type LIKE 'Psychic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM damage_type WHERE type LIKE 'Acid'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM damage_type WHERE type LIKE 'Cold'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM damage_type WHERE type LIKE 'Lightning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM damage_type WHERE type LIKE 'Thunder'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guardian of Faith'),(SELECT rowid FROM damage_type WHERE type LIKE 'Radiant'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guiding Bolt'),(SELECT rowid FROM damage_type WHERE type LIKE 'Radiant'));

INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM condition WHERE name LIKE 'Frightened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM condition WHERE name LIKE 'Unconscious'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Awaken'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM condition WHERE name LIKE 'Deafened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blink'),(SELECT rowid FROM condition WHERE name LIKE 'Invisible'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blur'),(SELECT rowid FROM condition WHERE name LIKE 'Invisible'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM condition WHERE name LIKE 'Prone'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Compulsion'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM condition WHERE name LIKE 'Confused'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contact Other Plane'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM condition WHERE name LIKE 'Poisoned'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM condition WHERE name LIKE 'Confused'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM condition WHERE name LIKE 'Stunned'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkness'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Word'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Word'),(SELECT rowid FROM condition WHERE name LIKE 'Deafened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Word'),(SELECT rowid FROM condition WHERE name LIKE 'Stunned'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Beast'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM condition WHERE name LIKE 'Unconscious'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM condition WHERE name LIKE 'Prone'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Entangle'),(SELECT rowid FROM condition WHERE name LIKE 'Restrained'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enthrall'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM condition WHERE name LIKE 'Invisible'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM condition WHERE name LIKE 'Poisoned'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM condition WHERE name LIKE 'Unconscious'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM condition WHERE name LIKE 'Frightened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM condition WHERE name LIKE 'Frightened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM condition WHERE name LIKE 'Restrained'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM condition WHERE name LIKE 'Petrified'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM condition WHERE name LIKE 'Restrained'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM condition WHERE name LIKE 'Prone'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM condition WHERE name LIKE 'Invisible'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM condition WHERE name LIKE 'Confused'));

INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Aid'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Messenger'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Shapes'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Dead'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antilife Shell'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antimagic Field'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Eye'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Lock'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Augury'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Awaken'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bane'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Barkskin'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Beacon of Hope'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blade Barrier'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bless'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blink'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blur'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Branding Smite'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Call Lightning'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Calm Emotions'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clone'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune with Nature'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Compulsion'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Animals'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Celestial'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Elemental'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Fey'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Minor Elementals'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Woodland Beings'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contact Other Plane'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contingency'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Continual Flame'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Weather'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Counterspell'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Food and Water'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create or Destroy Water'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Undead'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkness'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Death Ward'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Demiplane'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Evil and Good'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disguise Self'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divination'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Favor'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Word'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Beast'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Druidcraft'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eldritch Blast'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Entangle'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enthrall'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Expeditious Retreat'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fabricate'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'False Life'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Familiar'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Steed'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find the Path'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Traps'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Shield'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Blade'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forbiddance'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gate'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gentle Repose'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Giant Insect'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glibness'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Globe of Invulnerability'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Goodberry'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guardian of Faith'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guidance'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guiding Bolt'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));

INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Aid'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Aid'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Aid'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Messenger'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Messenger'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Messenger'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Shapes'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Dead'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Dead'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antilife Shell'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antimagic Field'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antimagic Field'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Eye'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Eye'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Lock'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Lock'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Augury'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Awaken'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Awaken'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bane'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bane'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Barkskin'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Barkskin'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Beacon of Hope'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blade Barrier'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bless'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bless'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blink'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blink'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blink'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blur'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blur'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blur'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Branding Smite'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Call Lightning'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Calm Emotions'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Calm Emotions'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clone'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune with Nature'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune with Nature'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Compulsion'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Animals'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Animals'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Celestial'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Elemental'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Elemental'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Fey'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Fey'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Minor Elementals'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Minor Elementals'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Woodland Beings'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Woodland Beings'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contact Other Plane'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contact Other Plane'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contingency'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Continual Flame'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Continual Flame'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Continual Flame'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Weather'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Weather'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Weather'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Counterspell'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Counterspell'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Counterspell'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Food and Water'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Food and Water'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Food and Water'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create or Destroy Water'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create or Destroy Water'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Undead'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Undead'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Undead'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkness'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkness'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkness'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Death Ward'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Death Ward'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Demiplane'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Demiplane'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Evil and Good'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Evil and Good'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disguise Self'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disguise Self'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disguise Self'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disguise Self'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divination'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Favor'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Word'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Beast'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Beast'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Druidcraft'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eldritch Blast'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Entangle'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enthrall'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enthrall'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Expeditious Retreat'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Expeditious Retreat'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Expeditious Retreat'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Expeditious Retreat'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fabricate'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fabricate'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'False Life'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'False Life'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'False Life'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Familiar'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Steed'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find the Path'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find the Path'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find the Path'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Traps'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Traps'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Traps'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Shield'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Blade'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forbiddance'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gate'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gate'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gate'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gentle Repose'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gentle Repose'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Giant Insect'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glibness'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glibness'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Globe of Invulnerability'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Globe of Invulnerability'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Goodberry'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Goodberry'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guardian of Faith'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guidance'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guidance'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guidance'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guiding Bolt'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));

INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Acid Splash'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Aid'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Aid'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Aid'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alarm'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Alter Self'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Friendship'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Messenger'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Messenger'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Messenger'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Shapes'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animal Shapes'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Dead'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Dead'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Dead'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Animate Objects'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antilife Shell'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antilife Shell'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antimagic Field'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antimagic Field'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antimagic Field'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Antipathy/Sympathy'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Eye'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Eye'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Eye'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Lock'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Lock'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Arcane Lock'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Astral Projection'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Augury'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Augury'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Augury'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Awaken'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Awaken'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Awaken'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bane'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bane'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bane'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Banishment'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Barkskin'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Barkskin'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Barkskin'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Beacon of Hope'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Beacon of Hope'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bestow Curse'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blade Barrier'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blade Barrier'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bless'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bless'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Bless'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blight'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blindness/Deafness'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blink'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blink'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Blur'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Branding Smite'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Burning Hands'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Call Lightning'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Call Lightning'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Calm Emotions'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Calm Emotions'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chain Lightning'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Charm Person'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Chill Touch'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Circle of Death'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clairvoyance'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clone'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clone'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Clone'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cloudkill'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Color Spray'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Command'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune with Nature'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Commune with Nature'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Comprehend Languages'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Compulsion'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Compulsion'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cone of Cold'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Confusion'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Animals'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Animals'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Celestial'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Celestial'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Elemental'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Elemental'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Elemental'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Fey'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Fey'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Minor Elementals'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Minor Elementals'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Woodland Beings'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Woodland Beings'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Conjure Woodland Beings'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contact Other Plane'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contagion'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contingency'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contingency'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Contingency'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Continual Flame'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Continual Flame'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Continual Flame'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Water'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Weather'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Weather'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Control Weather'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Counterspell'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Food and Water'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Food and Water'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create or Destroy Water'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create or Destroy Water'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create or Destroy Water'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Undead'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Undead'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Create Undead'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Creation'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Cure Wounds'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dancing Lights'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkness'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkness'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Darkvision'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Daylight'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Death Ward'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Death Ward'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Delayed Blast Fireball'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Demiplane'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Evil and Good'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Evil and Good'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Magic'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Poison and Disease'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Detect Thoughts'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dimension Door'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disguise Self'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disguise Self'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Disintegrate'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Evil and Good'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dispel Magic'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divination'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divination'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divination'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Favor'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Favor'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Divine Word'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Beast'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Beast'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Monster'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dominate Person'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Dream'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Druidcraft'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Druidcraft'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Earthquake'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eldritch Blast'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eldritch Blast'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enhance Ability'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enlarge/Reduce'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Entangle'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Entangle'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enthrall'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Enthrall'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Etherealness'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Expeditious Retreat'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Expeditious Retreat'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Eyebite'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fabricate'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fabricate'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Faerie Fire'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'False Life'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'False Life'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'False Life'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fear'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feather Fall'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Feeblemind'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Familiar'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Familiar'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Familiar'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Steed'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Steed'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find the Path'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find the Path'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find the Path'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Traps'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Find Traps'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Finger of Death'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fireball'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Bolt'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Shield'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Shield'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Shield'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fire Storm'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Blade'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Blade'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Blade'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flame Strike'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flaming Sphere'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Flesh to Stone'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fly'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Fog Cloud'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forbiddance'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forbiddance'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forbiddance'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Forcecage'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Foresight'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Freedom of Movement'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gaseous Form'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gate'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gate'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gate'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Geas'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gentle Repose'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gentle Repose'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gentle Repose'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Giant Insect'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Giant Insect'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glibness'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Globe of Invulnerability'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Globe of Invulnerability'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Globe of Invulnerability'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Glyph of Warding'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Goodberry'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Goodberry'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Goodberry'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Grease'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Invisibility'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Greater Restoration'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guardian of Faith'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guards and Wards'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guidance'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guidance'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guiding Bolt'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Guiding Bolt'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Gust of Wind'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));

COMMIT;
