BEGIN TRANSACTION;

INSERT OR IGNORE INTO source (shortname,name) VALUES
    ('SRD','Basic Rules');

INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a point and infuse an area around it with holy (or unholy) power. The area can have a radius up to 60 feet, and the spell fails if the radius includes an area already under the effect a hallow spell. The affected area is subject to the following effects.

First, celestials, elementals, fey, fiends, and undead can''t enter the area, nor can such creatures charm, frighten, or possess creatures within it. Any creature charmed, frightened, or possessed by such a creature is no longer charmed, frightened, or possessed upon entering the area. You can exclude one or more of those types of creatures from this effect.

Second, you can bind an extra effect to the area. Choose the effect from the following list, or choose an effect offered by the DM. Some of these effects apply to creatures in the area; you can designate whether the effect applies to all creatures, creatures that follow a specific deity or leader, or creatures of a specific sort, such as orcs or trolls. When a creature that would be affected enters the spell''s area for the first time on a turn or starts its turn there, it can make a Charisma saving throw. On a success, the creature ignores the extra effect until it leaves the area.

Courage. Affected creatures can''t be frightened while in the area.

Darkness. Darkness fills the area. Normal light, as well as magical light created by spells of a lower level than the slot you used to cast this spell, can''t illuminate the area.

Daylight. Bright light fills the area. Magical darkness created by spells of a lower level than the slot you used to cast this spell can''t extinguish the light.

Energy Protection. Affected creatures in the area have resistance to one damage type of your choice, except for bludgeoning, piercing, or slashing.

Energy Vulnerability. Affected creatures in the area have vulnerability to one damage type of your choice, except for bludgeoning, piercing, or slashing.

Everlasting Rest. Dead bodies interred in the area can''t be turned into undead.

Extradimensional Interference. Affected creatures can''t move or travel using teleportation or by extradimensional or interplanar means.

Fear. Affected creatures are frightened while in the area.

Silence. No sound can emanate from within the area, and no sound can reach into it.

Tongues. Affected creatures can communicate with any other creature in the area, even if they don''t share a common language.',NULL,'Until Dispelled','24 hours','Hallow',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),5,'Touch (60 feet)','Herbs, oils, and incense worth at least 1,000 gp, which the spell consumes',1000,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You make natural terrain in a 150-foot cube in range look, sound, and smell like some other sort of natural terrain. Thus, open fields or a road can be made to resemble a swamp, hill, crevasse, or some other difficult or impassable terrain. A pond can be made to seem like a grassy meadow, a precipice like a gentle slope, or a rock-strewn gully like a wide and smooth road. Manufactured structures, equipment, and creatures within the area aren''t changed in appearance.

The tactile characteristics of the terrain are unchanged, so creatures entering the area are likely to see through the illusion. If the difference isn''t obvious by touch, a creature carefully examining the illusion can attempt an Intelligence (Investigation) check against your spell save DC to disbelieve it. A creature who discerns the illusion for what it is, sees it as a vague image superimposed on the terrain.',NULL,'24 hours','10 minutes','Hallucinatory Terrain',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),4,'300 feet (150 feet)','A stone, a twig, and a bit of green plant',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You unleash a virulent disease on a creature that you can see within range. The target must make a Constitution saving throw. On a failed save, it takes 14d6 necrotic damage, or half as much damage on a successful save. The damage can''t reduce the target''s hit points below 1. If the target fails the saving throw, its hit point maximum is reduced for 1 hour by an amount equal to the necrotic damage it took. Any effect that removes a disease allows a creature''s hit point maximum to return to normal before that time passes.',NULL,'Instantaneous','1 action','Harm',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),6,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Choose a willing creature that you can see within range. Until the spell ends, the target''s speed is doubled, it gains a +2 bonus to AC, it has advantage on Dexterity saving throws, and it gains an additional action on each of its turns. That action can be used only to take the Attack (one weapon attack only), Dash, Disengage, Hide, or Use an Object action.

When the spell ends, the target can''t move or take actions until after its next turn, as a wave of lethargy sweeps over it.',NULL,'1 minute','1 action','Haste',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),3,'30 feet','A shaving of licorice root',0,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Choose a creature that you can see within range. A surge of positive energy washes through the creature, causing it to regain 70 hit points. This spell also ends blindness, deafness, and any diseases affecting the target. This spell has no effect on constructs or undead.','When you cast this spell using a spell slot of 7th level or higher, the amount of healing increases by 10 for each slot level above 6th.','Instantaneous','1 action','Heal',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),6,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A creature of your choice that you can see within range regains hit points equal to 1d4 + your spellcasting ability modifier. This spell has no effect on undead or constructs.','When you cast this spell using a spell slot of 2nd level or higher, the healing increases by 1d4 for each slot level above 1st.','Instantaneous','1 bonus action','Healing Word',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),1,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Choose a manufactured metal object, such as a metal weapon or a suit of heavy or medium metal armor, that you can see within range. You cause the object to glow red-hot. Any creature in physical contact with the object takes 2d8 fire damage when you cast the spell. Until the spell ends, you can use a bonus action on each of your subsequent turns to cause this damage again.

If a creature is holding or wearing the object and takes the damage from it, the creature must succeed on a Constitution saving throw or drop the object if it can. If it doesn''t drop the object, it has disadvantage on attack rolls and ability checks until the start of your next turn.','When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d8 for each slot level above 2nd.','1 minute','1 action','Heat Metal',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'60 feet','A piece of iron and a flame',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You point your finger, and the creature that damaged you is momentarily surrounded by hellish flames. The creature must make a Dexterity saving throw. It takes 2d10 fire damage on a failed save, or half as much damage on a successful one.','When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d10 for each slot level above 1st.','Instantaneous','1 reaction','Hellish Rebuke',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),1,'60 feet',NULL,NULL,'which you take in response to being damaged by a creature within 60 feet of you that you can see');
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You bring forth a great feast, including magnificent food and drink. The feast takes 1 hour to consume and disappears at the end of that time, and the beneficial effects don''t set in until this hour is over. Up to twelve creatures can partake of the feast.

A creature that partakes of the feast gains several benefits. The creature is cured of all diseases and poison, becomes immune to poison and being frightened, and makes all Wisdom saving throws with advantage. Its hit point maximum also increases by 2d10, and it gains the same number of hit points. These benefits last for 24 hours.',NULL,'Instantaneous','10 minutes','Heroes'' Feast',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),6,'30 feet','A gem-encrusted bowl worth at least 1,000 gp, which the spell consumes',1000,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A willing creature you touch is imbued with bravery. Until the spell ends, the creature is immune to being frightened and gains temporary hit points equal to your spellcasting ability modifier at the start of each of its turns. When the spell ends, the target loses any remaining temporary hit points from this spell.','When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st.','1 minute','1 action','Heroism',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),1,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Choose a creature that you can see within range. The target must succeed on a Wisdom saving throw or be paralyzed for the duration. This spell has no effect on undead. At the end of each of its turns, the target can make another Wisdom saving throw. On a success, the spell ends on the target.','When you cast this spell using a spell slot of 6th level or higher, you can target one additional creature for each slot level above 5th. The creatures must be within 30 feet of each other when you target them.','1 minute','1 action','Hold Monster',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),5,'90 feet','A small, straight piece of iron',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Choose a humanoid that you can see within range. The target must succeed on a Wisdom saving throw or be paralyzed for the duration. At the end of each of its turns, the target can make another Wisdom saving throw. On a success, the spell ends on the target.','When you cast this spell using a spell slot of 3rd level or higher, you can target one additional humanoid for each slot level above 2nd. The humanoids must be within 30 feet of each other when you target them.','1 minute','1 action','Hold Person',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),2,'60 feet','A small, straight piece of iron',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Divine light washes out from you and coalesces in a soft radiance in a 30-foot radius around you. Creatures of your choice in that radius when you cast this spell shed dim light in a 5-foot radius and have advantage on all saving throws, and other creatures have disadvantage on attack rolls against them until the spell ends. In addition, when a fiend or an undead hits an affected creature with a melee attack, the aura flashes with brilliant light. The attacker must succeed on a Constitution saving throw or be blinded until the spell ends.',NULL,'1 minute','1 action','Holy Aura',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),8,'Self (30 feet)','A tiny reliquary worth at least 1,000 gp containing a sacred relic, such as a scrap of cloth from a saint''s robe or a piece of parchment from a religious text',1000,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You choose a creature you can see within range and mystically mark it as your quarry. Until the spell ends, you deal an extra 1d6 damage to the target whenever you hit it with a weapon attack, and you have advantage on any Wisdom (Perception) or Wisdom (Survival) check you make to find it. If the target drops to 0 hit points before this spell ends, you can use a bonus action on a subsequent turn of yours to mark a new creature.','When you cast this spell using a spell slot of 3rd or 4th level, you can maintain your concentration on the spell for up to 8 hours. When you use a spell slot of 5th level or higher, you can maintain your concentration on the spell for up to 24 hours.','1 hour','1 bonus action','Hunter''s Mark',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),1,'90 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create a twisting pattern of colors that weaves through the air inside a 30-foot cube within range. The pattern appears for a moment and vanishes. Each creature in the area who sees the pattern must make a Wisdom saving throw. On a failed save, the creature becomes charmed for the duration. While charmed by this spell, the creature is incapacitated and has a speed of 0.

The spell ends for an affected creature if it takes any damage or if someone else uses an action to shake the creature out of its stupor.',NULL,'1 minute','1 action','Hypnotic Pattern',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),3,'120 feet (30 feet)','A glowing stick of incense or a crystal vial filled with phosphorescent material',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A hail of rock-hard ice pounds to the ground in a 20-foot-radius, 40-foot-high cylinder centered on a point within range. Each creature in the cylinder must make a Dexterity saving throw. A creature takes 2d8 bludgeoning damage and 4d6 cold damage on a failed save, or half as much damage on a successful one.

Hailstones turn the storm''s area of effect into difficult terrain until the end of your next turn.','When you cast this spell using a spell slot of 5th level or higher, the bludgeoning damage increases by 1d8 for each slot level above 4th.','Instantaneous','1 action','Ice Storm',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),4,'300 feet (20 feet)','A pinch of dust and a few drops of water',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You choose one object that you must touch throughout the casting of the spell. If it is a magic item or some other magic-imbued object, you learn its properties and how to use them, whether it requires attunement to use, and how many charges it has, if any. You learn whether any spells are affecting the item and what they are. If the item was created by a spell, you learn which spell created it.

If you instead touch a creature throughout the casting, you learn what spells, if any, are currently affecting it.',NULL,'Instantaneous','1 minute','Identify',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),1,'Touch','A pearl worth at least 100 gp and an owl feather',100,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You write on parchment, paper, or some other suitable writing material and imbue it with a potent illusion that lasts for the duration.

To you and any creatures you designate when you cast the spell, the writing appears normal, written in your hand, and conveys whatever meaning you intended when you wrote the text. To all others, the writing appears as if it were written in an unknown or magical script that is unintelligible. Alternatively, you can cause the writing to appear to be an entirely different message, written in a different hand and language, though the language must be one you know.

Should the spell be dispelled, the original script and the illusion both disappear.

A creature with truesight can read the hidden message.',NULL,'10 days','1 minute','Illusory Script',1,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),1,'Touch','A lead-based ink worth at least 10 gp, which the spell consumes',10,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create a magical restraint to hold a creature that you can see within range. The target must succeed on a Wisdom saving throw or be bound by the spell; if it succeeds, it is immune to this spell if you cast it again. While affected by this spell, the creature doesn''t need to breathe, eat, or drink, and it doesn''t age. Divination spells can''t locate or perceive the target.

When you cast the spell, you choose one of the following forms of imprisonment.

Burial. The target is entombed far beneath the earth in a sphere of magical force that is just large enough to contain the target. Nothing can pass through the sphere, nor can any creature teleport or use planar travel to get into or out of it.

The special component for this version of the spell is a small mithral orb.

Chaining. Heavy chains, firmly rooted in the ground, hold the target in place. The target is restrained until the spell ends, and it can''t move or be moved by any means until then.

The special component for this version of the spell is a fine chain of precious metal.

Hedged Prison. The spell transports the target into a tiny demiplane that is warded against teleportation and planar travel. The demiplane can be a labyrinth, a cage, a tower, or any similar confined structure or area of your choice.

The special component for this version of the spell is a miniature representation of the prison made from jade.

Minimus Containment. The target shrinks to a height of 1 inch and is imprisoned inside a gemstone or similar object. Light can pass through the gemstone normally (allowing the target to see out and other creatures to see in), but nothing else can pass through, even by means of teleportation or planar travel. The gemstone can''t be cut or broken while the spell remains in effect.

The special component for this version of the spell is a large, transparent gemstone, such as a corundum, diamond, or ruby.

Slumber. The target falls asleep and can''t be awoken. The special component for this version of the spell consists of rare soporific herbs.

Ending the Spell. During the casting of the spell, in any of its versions, you can specify a condition that will cause the spell to end and release the target. The condition can be as specific or as elaborate as you choose, but the DM must agree that the condition is reasonable and has a likelihood of coming to pass. The conditions can be based on a creature''s name, identity, or deity but otherwise must be based on observable actions or qualities and not based on intangibles such as level, class, or hit points.

A dispel magic spell can end the spell only if it is cast as a 9th-level spell, targeting either the prison or the special component used to create it.

You can use a particular special component to create only one prison at a time. If you cast the spell again using the same component, the target of the first casting is immediately freed from its binding.',NULL,'Until Dispelled','1 minute','Imprisonment',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),9,'30 feet','A vellum depiction or a carved statuette in the likeness of the target, and a special component that varies according to the version of the spell you choose, worth at least 500 gp per Hit Die of the target',500,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A swirling cloud of smoke shot through with white-hot embers appears in a 20-foot-radius sphere centered on a point within range. The cloud spreads around corners and is heavily obscured. It lasts for the duration or until a wind of moderate or greater speed (at least 10 miles per hour) disperses it.

When the cloud appears, each creature in it must make a Dexterity saving throw. A creature takes 10d8 fire damage on a failed save, or half as much damage on a successful one. A creature must also make this saving throw when it enters the spell''s area for the first time on a turn or ends its turn there.

The cloud moves 10 feet directly away from you in a direction that you choose at the start of each of your turns.',NULL,'1 minute','1 action','Incendiary Cloud',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),8,'150 feet (20 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Make a melee spell attack against a creature you can reach. On a hit, the target takes 3d10 necrotic damage.','When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d10 for each slot level above 1st.','Instantaneous','1 action','Inflict Wounds',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),1,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Swarming, biting locusts fill a 20-foot-radius sphere centered on a point you choose within range. The sphere spreads around corners. The sphere remains for the duration, and its area is lightly obscured. The sphere''s area is difficult terrain.

When the area appears, each creature in it must make a Constitution saving throw. A creature takes 4d10 piercing damage on a failed save, or half as much damage on a successful one. A creature must also make this saving throw when it enters the spell''s area for the first time on a turn or ends its turn there.','When you cast this spell using a spell slot of 6th level or higher, the damage increases by 1d10 for each slot level above 5th.','10 minutes','1 action','Insect Plague',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),5,'300 feet (20 feet)','A few grains of sugar, some kernels of grain, and a smear of fat',0,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A creature you touch becomes invisible until the spell ends. Anything the target is wearing or carrying is invisible as long as it is on the target''s person. The spell ends for a target that attacks or casts a spell.','When you cast this spell using a spell slot of 3rd level or higher, you can target one additional creature for each slot level above 2nd.','1 hour','1 action','Invisibility',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),2,'Touch','An eyelash encased in gum arabic',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a creature. The creature''s jump distance is tripled until the spell ends.',NULL,'1 minute','1 action','Jump',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),1,'Touch','A grasshopper''s hind leg',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Choose an object that you can see within range. The object can be a door, a box, a chest, a set of manacles, a padlock, or another object that contains a mundane or magical means that prevents access.

A target that is held shut by a mundane lock or that is stuck or barred becomes unlocked, unstuck, or unbarred. If the object has multiple locks, only one of them is unlocked.

If you choose a target that is held shut with arcane lock, that spell is suppressed for 10 minutes, during which time the target can be opened and shut normally.

When you cast the spell, a loud knock, audible from as far away as 300 feet, emanates from the target object.',NULL,'Instantaneous','1 action','Knock',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'60 feet',NULL,NULL,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Name or describe a person, place, or object. The spell brings to your mind a brief summary of the significant lore about the thing you named. The lore might consist of current tales, forgotten stories, or even secret lore that has never been widely known. If the thing you named isn''t of legendary importance, you gain no information. The more information you already have about the thing, the more precise and detailed the information you receive is.

The information you learn is accurate but might be couched in figurative language. For example, if you have a mysterious magic axe on hand, the spell might yield this information: "Woe to the evildoer whose hand touches the axe, for even the haft slices the hand of the evil ones. Only a true Child of Stone, lover and beloved of Moradin, may awaken the true powers of the axe, and only with the sacred word Rudnogg on the lips."',NULL,'Instantaneous','10 minutes','Legend Lore',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),5,'Self','Incense worth at least 250 gp, which the spell consumes, and four ivory strips worth at least 50 gp each',450,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a creature and can end either one disease or one condition afflicting it. The condition can be blinded, deafened, paralyzed, or poisoned.',NULL,'Instantaneous','1 action','Lesser Restoration',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),2,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'One creature or loose object of your choice that you can see within range rises vertically, up to 20 feet, and remains suspended there for the duration. The spell can levitate a target that weighs up to 500 pounds. An unwilling creature that succeeds on a Constitution saving throw is unaffected.

The target can move only by pushing or pulling against a fixed object or surface within reach (such as a wall or a ceiling), which allows it to move as if it were climbing. You can change the target''s altitude by up to 20 feet in either direction on your turn. If you are the target, you can move up or down as part of your move. Otherwise, you can use your action to move the target, which must remain within the spell''s range.

When the spell ends, the target floats gently to the ground if it is still aloft.',NULL,'10 minutes','1 action','Levitate',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'60 feet','Either a small leather loop or a piece of golden wire bent into a cup shape with a long shank on one end',0,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch one object that is no larger than 10 feet in any dimension. Until the spell ends, the object sheds bright light in a 20-foot radius and dim light for an additional 20 feet. The light can be colored as you like. Completely covering the object with something opaque blocks the light. The spell ends if you cast it again or dismiss it as an action.

If you target an object held or worn by a hostile creature, that creature must succeed on a Dexterity saving throw to avoid the spell.',NULL,'1 hour','1 action','Light',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),0,'Touch','A firefly or phosphorescent moss',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A stroke of lightning forming a line 100 feet long and 5 feet wide blasts out from you in a direction you choose. Each creature in the line must make a Dexterity saving throw. A creature takes 8d6 lightning damage on a failed save, or half as much damage on a successful one.

The lightning ignites flammable objects in the area that aren''t being worn or carried.','When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d6 for each slot level above 3rd.','Instantaneous','1 action','Lightning Bolt',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),3,'Self (100 feet)','A bit of fur and a rod of amber, crystal, or glass',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Describe or name a specific kind of beast or plant. Concentrating on the voice of nature in your surroundings, you learn the direction and distance to the closest creature or plant of that kind within 5 miles, if any are present.',NULL,'Instantaneous','1 action','Locate Animals or Plants',1,(SELECT rowid FROM school WHERE name LIKE 'Divination'),2,'Self','A bit of fur from a bloodhound',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Describe or name a creature that is familiar to you. You sense the direction to the creature''s location, as long as that creature is within 1,000 feet of you. If the creature is moving, you know the direction of its movement.

The spell can locate a specific creature known to you, or the nearest creature of a specific kind (such as a human or a unicorn), so long as you have seen such a creature up close—within 30 feet—at least once. If the creature you described or named is in a different form, such as being under the effects of a polymorph spell, this spell doesn''t locate the creature.

This spell can''t locate a creature if running water at least 10 feet wide blocks a direct path between you and the creature.',NULL,'1 hour','1 action','Locate Creature',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),4,'Self','A bit of fur from a bloodhound',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Describe or name an object that is familiar to you. You sense the direction to the object''s location, as long as that object is within 1,000 feet of you. If the object is in motion, you know the direction of its movement.

The spell can locate a specific object known to you, as long as you have seen it up close—within 30 feet—at least once. Alternatively, the spell can locate the nearest object of a particular kind, such as a certain kind of apparel, jewelry, furniture, tool, or weapon.

This spell can''t locate an object if any thickness of lead, even a thin sheet, blocks a direct path between you and the object.',NULL,'10 minutes','1 action','Locate Object',0,(SELECT rowid FROM school WHERE name LIKE 'Divination'),2,'Self','A forked twig',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a creature. The target''s speed increases by 10 feet until the spell ends.','When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st.','1 hour','1 action','Longstrider',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),1,'Touch','A pinch of dirt',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a willing creature who isn''t wearing armor, and a protective magical force surrounds it until the spell ends. The target''s base AC becomes 13 + its Dexterity modifier. The spell ends if the target dons armor or if you dismiss the spell as an action.',NULL,'8 hours','1 action','Mage Armor',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),1,'Touch','A piece of cured leather',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A spectral, floating hand appears at a point you choose within range. The hand lasts for the duration or until you dismiss it as an action. The hand vanishes if it is ever more than 30 feet away from you or if you cast this spell again.

You can use your action to control the hand. You can use the hand to manipulate an object, open an unlocked door or container, stow or retrieve an item from an open container, or pour the contents out of a vial. You can move the hand up to 30 feet each time you use it.

The hand can''t attack, activate magic items, or carry more than 10 pounds.',NULL,'1 minute','1 action','Mage Hand',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),0,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create a 10-foot-radius, 20-foot-tall cylinder of magical energy centered on a point on the ground that you can see within range. Glowing runes appear wherever the cylinder intersects with the floor or other surface.

Choose one or more of the following types of creatures: celestials, elementals, fey, fiends, or undead. The circle affects a creature of the chosen type in the following ways:

- The creature can''t willingly enter the cylinder by nonmagical means. If the creature tries to use teleportation or interplanar travel to do so, it must first succeed on a Charisma saving throw.
- The creature has disadvantage on attack rolls against targets within the cylinder.
- Targets within the cylinder can''t be charmed, frightened, or possessed by the creature.

When you cast this spell, you can elect to cause its magic to operate in the reverse direction, preventing a creature of the specified type from leaving the cylinder and protecting targets outside it.','When you cast this spell using a spell slot of 4th level or higher, the duration increases by 1 hour for each slot level above 3rd.','1 hour','1 minute','Magic Circle',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),3,'10 feet (10 feet)','Holy water or powdered silver and iron worth at least 100 gp, which the spell consumes',100,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Your body falls into a catatonic state as your soul leaves it and enters the container you used for the spell''s material component. While your soul inhabits the container, you are aware of your surroundings as if you were in the container''s space. You can''t move or use reactions. The only action you can take is to project your soul up to 100 feet out of the container, either returning to your living body (and ending the spell) or attempting to possess a humanoids body.

You can attempt to possess any humanoid within 100 feet of you that you can see (creatures warded by a protection from evil and good or magic circle spell can''t be possessed). The target must make a Charisma saving throw. On a failure, your soul moves into the target''s body, and the target''s soul becomes trapped in the container. On a success, the target resists your efforts to possess it, and you can''t attempt to possess it again for 24 hours.

Once you possess a creature''s body, you control it. Your game statistics are replaced by the statistics of the creature, though you retain your alignment and your Intelligence, Wisdom, and Charisma scores. You retain the benefit of your own class features. If the target has any class levels, you can''t use any of its class features.

Meanwhile, the possessed creature''s soul can perceive from the container using its own senses, but it can''t move or take actions at all.

While possessing a body, you can use your action to return from the host body to the container if it is within 100 feet of you, returning the host creature''s soul to its body. If the host body dies while you''re in it, the creature dies, and you must make a Charisma saving throw against your own spellcasting DC. On a success, you return to the container if it is within 100 feet of you. Otherwise, you die.

If the container is destroyed or the spell ends, your soul immediately returns to your body. If your body is more than 100 feet away from you or if your body is dead when you attempt to return to it, you die. If another creature''s soul is in the container when it is destroyed, the creature''s soul returns to its body if the body is alive and within 100 feet. Otherwise, that creature dies.

When the spell ends, the container is destroyed.',NULL,'Until Dispelled','1 minute','Magic Jar',0,(SELECT rowid FROM school WHERE name LIKE 'Necromancy'),6,'Self','A gem, crystal, reliquary, or some other ornamental container worth at least 500 gp',500,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create three glowing darts of magical force. Each dart hits a creature of your choice that you can see within range. A dart deals 1d4 + 1 force damage to its target. The darts all strike simultaneously, and you can direct them to hit one creature or several.','When you cast this spell using a spell slot of 2nd level or higher, the spell creates one more dart for each slot level above 1st.','Instantaneous','1 action','Magic Missile',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),1,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You implant a message within an object in range, a message that is uttered when a trigger condition is met. Choose an object that you can see and that isn''t being worn or carried by another creature. Then speak the message, which must be 25 words or less, though it can be delivered over as long as 10 minutes. Finally, determine the circumstance that will trigger the spell to deliver your message.

When that circumstance occurs, a magical mouth appears on the object and recites the message in your voice and at the same volume you spoke. If the object you chose has a mouth or something that looks like a mouth (for example, the mouth of a statue), the magical mouth appears there so that the words appear to come from the object''s mouth. When you cast this spell, you can have the spell end after it delivers its message, or it can remain and repeat its message whenever the trigger occurs.

The triggering circumstance can be as general or as detailed as you like, though it must be based on visual or audible conditions that occur within 30 feet of the object. For example, you could instruct the mouth to speak when any creature moves within 30 feet of the object or when a silver bell rings within 30 feet of it.',NULL,'Until Dispelled','1 minute','Magic Mouth',1,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),2,'30 feet','A small bit of honeycomb and jade dust worth at least 10 gp, which the spell consumes',10,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You touch a nonmagical weapon. Until the spell ends, that weapon becomes a magic weapon with a +1 bonus to attack rolls and damage rolls.','When you cast this spell using a spell slot of 4th level or higher, the bonus increases to +2. When you use a spell slot of 6th level or higher, the bonus increases to +3.','1 hour','1 bonus action','Magic Weapon',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),2,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create the image of an object, a creature, or some other visible phenomenon that is no larger than a 20-foot cube. The image appears at a spot that you can see within range and lasts for the duration. It seems completely real, including sounds, smells, and temperature appropriate to the thing depicted. You can''t create sufficient heat or cold to cause damage, a sound loud enough to deal thunder damage or deafen a creature, or a smell that might sicken a creature (like a troglodyte''s stench).

As long as you are within range of the illusion, you can use your action to cause the image to move to any other spot within range. As the image changes location, you can alter its appearance so that its movements appear natural for the image. For example, if you create an image of a creature and move it, you can alter the image so that it appears to be walking. Similarly, you can cause the illusion to make different sounds at different times, even making it carry on a conversation, for example.

Physical interaction with the image reveals it to be an illusion, because things can pass through it. A creature that uses its action to examine the image can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the creature can see through the image, and its other sensory qualities become faint to the creature.','When you cast this spell using a spell slot of 6th level or higher, the spell lasts until dispelled, without requiring your concentration.','10 minutes','1 action','Major Image',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),3,'120 feet (20 feet)','A bit of fleece',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A wave of healing energy washes out from a point of your choice within range. Choose up to six creatures in a 30-foot-radius sphere centered on that point. Each target regains hit points equal to 3d8 + your spellcasting ability modifier. This spell has no effect on undead or constructs.','When you cast this spell using a spell slot of 6th level or higher, the healing increases by 1d8 for each slot level above 5th.','Instantaneous','1 action','Mass Cure Wounds',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),5,'60 feet (30 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A flood of healing energy flows from you into injured creatures around you. You restore up to 700 hit points, divided as you choose among any number of creatures that you can see within range. Creatures healed by this spell are also cured of all diseases and any effect making them blinded or deafened. This spell has no effect on undead or constructs.',NULL,'Instantaneous','1 action','Mass Heal',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),9,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'As you call out words of restoration, up to six creatures of your choice that you can see within range regain hit points equal to 1d4 + your spellcasting ability modifier. This spell has no effect on undead or constructs.','When you cast this spell using a spell slot of 4th level or higher, the healing increases by 1d4 for each slot level above 3rd.','Instantaneous','1 bonus action','Mass Healing Word',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),3,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You suggest a course of activity (limited to a sentence or two) and magically influence up to twelve creatures of your choice that you can see within range and that can hear and understand you. Creatures that can''t be charmed are immune to this effect. The suggestion must be worded in such a manner as to make the course of action sound reasonable. Asking the creature to stab itself, throw itself onto a spear, immolate itself, or do some other obviously harmful act automatically negates the effect of the spell.

Each target must make a Wisdom saving throw. On a failed save, it pursues the course of action you described to the best of its ability. The suggested course of action can continue for the entire duration. If the suggested activity can be completed in a shorter time, the spell ends when the subject finishes what it was asked to do.

You can also specify conditions that will trigger a special activity during the duration. For example, you might suggest that a group of soldiers give all their money to the first beggar they meet. If the condition isn''t met before the spell ends, the activity isn''t performed.

If you or any of your companions damage a creature affected by this spell, the spell ends for that creature.','When you cast this spell using a 7th-level spell slot, the duration is 10 days. When you use an 8th-level spell slot, the duration is 30 days. When you use a 9th-level spell slot, the duration is a year and a day.','24 hours','1 action','Mass Suggestion',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),6,'60 feet','A snake''s tongue and either a bit of honeycomb or a drop of sweet oil',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You banish a creature that you can see within range into a labyrinthine demiplane. The target remains there for the duration or until it escapes the maze.

The target can use its action to attempt to escape. When it does so, it makes a DC 20 Intelligence check. If it succeeds, it escapes, and the spell ends (a minotaur or goristro demon automatically succeeds).

When the spell ends, the target reappears in the space it left or, if that space is occupied, in the nearest unoccupied space.',NULL,'10 minutes','1 action','Maze',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),8,'60 feet',NULL,NULL,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You step into a stone object or surface large enough to fully contain your body, melding yourself and all the equipment you carry with the stone for the duration. Using your movement, you step into the stone at a point you can touch. Nothing of your presence remains visible or otherwise detectable by nonmagical senses.

While merged with the stone, you can''t see what occurs outside it, and any Wisdom (Perception) checks you make to hear sounds outside it are made with disadvantage. You remain aware of the passage of time and can cast spells on yourself while merged in the stone. You can use your movement to leave the stone where you entered it, which ends the spell. You otherwise can''t move.

Minor physical damage to the stone doesn''t harm you, but its partial destruction or a change in its shape (to the extent that you no longer fit within it) expels you and deals 6d6 bludgeoning damage to you. The stone''s complete destruction (or transmutation into a different substance) expels you and deals 50 bludgeoning damage to you. If expelled, you fall prone in an unoccupied space closest to where you first entered.',NULL,'8 hours','1 action','Meld into Stone',1,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),3,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'This spell repairs a single break or tear in an object you touch, such as a broken chain link, two halves of a broken key, a torn cloak, or a leaking wineskin. As long as the break or tear is no larger than 1 foot in any dimension, you mend it, leaving no trace of the former damage.

This spell can physically repair a magic item or construct, but the spell can''t restore magic to such an object.',NULL,'Instantaneous','1 minute','Mending',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),0,'Touch','Two lodestones',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You point your finger toward a creature within range and whisper a message. The target (and only the target) hears the message and can reply in a whisper that only you can hear.

You can cast this spell through solid objects if you are familiar with the target and know it is beyond the barrier. Magical silence, 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood blocks the spell. The spell doesn''t have to follow a straight line and can travel freely around corners or through openings.',NULL,'1 round','1 action','Message',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),0,'120 feet','A short piece of copper wire',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Blazing orbs of fire plummet to the ground at four different points you can see within range. Each creature in a 40-foot-radius sphere centered on each point you choose must make a Dexterity saving throw. The sphere spreads around corners. A creature takes 20d6 fire damage and 20d6 bludgeoning damage on a failed save, or half as much damage on a successful one. A creature in the area of more than one fiery burst is affected only once.

The spell damages objects in the area and ignites flammable objects that aren''t being worn or carried.',NULL,'Instantaneous','1 action','Meteor Swarm',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),9,'1 mile',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Until the spell ends, one willing creature you touch is immune to psychic damage, any effect that would sense its emotions or read its thoughts, divination spells, and the charmed condition. The spell even foils wish spells and spells or effects of similar power used to affect the target''s mind or to gain information about the target.',NULL,'24 hours','1 action','Mind Blank',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),8,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create a sound or an image of an object within range that lasts for the duration. The illusion also ends if you dismiss it as an action or cast this spell again.

If you create a sound, its volume can range from a whisper to a scream. It can be your voice, someone else''s voice, a lion''s roar, a beating of drums, or any other sound you choose. The sound continues unabated throughout the duration, or you can make discrete sounds at different times before the spell ends.

If you create an image of an object—such as a chair, muddy footprints, or a small chest—it must be no larger than a 5-foot cube. The image can''t create sound, light, smell, or any other sensory effect. Physical interaction with the image reveals it to be an illusion, because things can pass through it.

If a creature uses its action to examine the sound or image, the creature can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the illusion becomes faint to the creature.',NULL,'1 minute','1 action','Minor Illusion',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),0,'30 feet (5 feet)','A bit of fleece',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You make terrain in an area up to 1 mile square look, sound, smell, and even feel like some other sort of terrain. The terrain''s general shape remains the same, however. Open fields or a road could be made to resemble a swamp, hill, crevasse, or some other difficult or impassable terrain. A pond can be made to seem like a grassy meadow, a precipice like a gentle slope, or a rock-strewn gully like a wide and smooth road.

Similarly, you can alter the appearance of structures, or add them where none are present. The spell doesn''t disguise, conceal, or add creatures.

The illusion includes audible, visual, tactile, and olfactory elements, so it can turn clear ground into difficult terrain (or vice versa) or otherwise impede movement through the area. Any piece of the illusory terrain (such as a rock or stick) that is removed from the spell''s area disappears immediately.

Creatures with truesight can see through the illusion to the terrain''s true form; however, all other elements of the illusion remain, so while the creature is aware of the illusion''s presence, the creature can still physically interact with the illusion.',NULL,'10 days','10 minutes','Mirage Arcane',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),7,'1 mile',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Three illusory duplicates of yourself appear in your space. Until the spell ends, the duplicates move with you and mimic your actions, shifting position so it''s impossible to track which image is real. You can use your action to dismiss the illusory duplicates.

Each time a creature targets you with an attack during the spell''s duration, roll a d20 to determine whether the attack instead targets one of your duplicates.

If you have three duplicates, you must roll a 6 or higher to change the attack''s target to a duplicate. With two duplicates, you must roll an 8 or higher. With one duplicate, you must roll an 11 or higher.

A duplicate''s AC equals 10 + your Dexterity modifier. If an attack hits a duplicate, the duplicate is destroyed. A duplicate can be destroyed only by an attack that hits it. It ignores all other damage and effects. The spell ends when all three duplicates are destroyed.

A creature is unaffected by this spell if it can''t see, if it relies on senses other than sight, such as blindsight, or if it can perceive illusions as false, as with truesight.',NULL,'1 minute','1 action','Mirror Image',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),2,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You become invisible at the same time that an illusory double of you appears where you are standing. The double lasts for the duration, but the invisibility ends if you attack or cast a spell.

You can use your action to move your illusory double up to twice your speed and make it gesture, speak, and behave in whatever way you choose.

You can see through its eyes and hear through its ears as if you were located where it is. On each of your turns as a bonus action, you can switch from using its senses to using your own, or back again. While you are using its senses, you are blinded and deafened in regard to your own surroundings.',NULL,'1 hour','1 action','Mislead',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),5,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Briefly surrounded by silvery mist, you teleport up to 30 feet to an unoccupied space that you can see.',NULL,'Instantaneous','1 bonus action','Misty Step',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),2,'Self',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You attempt to reshape another creature''s memories. One creature that you can see must make a Wisdom saving throw. If you are fighting the creature, it has advantage on the saving throw. On a failed save, the target becomes charmed by you for the duration. The charmed target is incapacitated and unaware of its surroundings, though it can still hear you. If it takes any damage or is targeted by another spell, this spell ends, and none of the target''s memories are modified.

While this charm lasts, you can affect the target''s memory of an event that it experienced within the last 24 hours and that lasted no more than 10 minutes. You can permanently eliminate all memory of the event, allow the target to recall the event with perfect clarity and exacting detail, change its memory of the details of the event, or create a memory of some other event.

You must speak to the target to describe how its memories are affected, and it must be able to understand your language for the modified memories to take root. Its mind fills in any gaps in the details of your description. If the spell ends before you have finished describing the modified memories, the creature''s memory isn''t altered. Otherwise, the modified memories take hold when the spell ends.

A modified memory doesn''t necessarily affect how a creature behaves, particularly if the memory contradicts the creature''s natural inclinations, alignment, or beliefs. An illogical modified memory, such as implanting a memory of how much the creature enjoyed dousing itself in acid, is dismissed, perhaps as a bad dream. The DM might deem a modified memory too nonsensical to affect a creature in a significant manner.

A remove curse or greater restoration spell cast on the target restores the creature''s true memory.','If you cast this spell using a spell slot of 6th level or higher, you can alter the target''s memories of an event that took place up to 7 days ago (6th level), 30 days ago (7th level), 1 year ago (8th level), or any time in the creature''s past (9th level).','1 minute','1 action','Modify Memory',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),5,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A silvery beam of pale light shines down in a 5-foot-radius, 40-foot-high cylinder centered on a point within range. Until the spell ends, dim light fills the cylinder.

When a creature enters the spell''s area for the first time on a turn or starts its turn there, it is engulfed in ghostly flames that cause searing pain, and it must make a Constitution saving throw. It takes 2d10 radiant damage on a failed save, or half as much damage on a successful one.

A shapechanger makes its saving throw with disadvantage. If it fails, it also instantly reverts to its original form and can''t assume a different form until it leaves the spell''s light.

On your turns after you cast this spell, you can use an action to move the beam up to 60 feet in any direction.','When you cast this spell using a spell slot of 3rd level or higher, the damage increases by 1d10 for each slot level above 2nd.','1 minute','1 action','Moonbeam',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),2,'120 feet (5 feet)','Several seeds of any moonseed plant and a piece of opalescent feldspar',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create a sword-shaped plane of force that hovers within range. It lasts for the duration.

When the sword appears, you make a melee spell attack against a target of your choice within 5 feet of the sword. On a hit, the target takes 3d10 force damage. Until the spell ends, you can use a bonus action on each of your turns to move the sword up to 20 feet to a spot you can see and repeat this attack against the same target or a different one.',NULL,'1 minute','1 action','Mordenkainen''s Sword',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),7,'60 feet','A miniature platinum sword with a grip and pommel of copper and zinc, worth 250 gp',250,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Choose an area of terrain no larger than 40 feet on a side within range. You can reshape dirt, sand, or clay in the area in any manner you choose for the duration. You can raise or lower the area''s elevation, create or fill in a trench, erect or flatten a wall, or form a pillar. The extent of any such changes can''t exceed half the area''s largest dimension. So, if you affect a 40-foot square, you can create a pillar up to 20 feet high, raise or lower the square''s elevation by up to 20 feet, dig a trench up to 20 feet deep, and so on. It takes 10 minutes for these changes to complete.

At the end of every 10 minutes you spend concentrating on the spell, you can choose a new area of terrain to affect.

Because the terrain''s transformation occurs slowly, creatures in the area can''t usually be trapped or injured by the ground''s movement.

This spell can''t manipulate natural stone or stone construction. Rocks and structures shift to accommodate the new terrain. If the way you shape the terrain would make a structure unstable, it might collapse.

Similarly, this spell doesn''t directly affect plant growth. The moved earth carries any plants along with it.',NULL,'2 hours','1 action','Move Earth',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),6,'120 feet','An iron blade and a small bag containing a mixture of soils--clay, loam, and sand',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'For the duration, you hide a target that you touch from divination magic. The target can be a willing creature or a place or an object no larger than 10 feet in any dimension. The target can''t be targeted by any divination magic or perceived through magical scrying sensors.',NULL,'8 hours','1 action','Nondetection',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),3,'Touch','A pinch of diamond dust worth 25 gp sprinkled over the target, which the spell consumes',25,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Choose one creature that you can see within range. The target begins a comic dance in place: shuffling, tapping its feet, and capering for the duration. Creatures that can''t be charmed are immune to this spell.

A dancing creature must use all its movement to dance without leaving its space and has disadvantage on Dexterity saving throws and attack rolls. While the target is affected by this spell, other creatures have advantage on attack rolls against it. As an action, a dancing creature makes a Wisdom saving throw to regain control of itself. On a successful save, the spell ends.',NULL,'1 minute','1 action','Otto''s Irresistible Dance',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),6,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'A veil of shadows and silence radiates from you, masking you and your companions from detection. For the duration, each creature you choose within 30 feet of you (including you) has a +10 bonus to Dexterity (Stealth) checks and can''t be tracked except by magical means. A creature that receives this bonus leaves behind no tracks or other traces of its passage.',NULL,'1 hour','1 action','Pass without Trace',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),2,'Self','Ashes from a burned leaf of mistletoe and a sprig of spruce',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A passage appears at a point of your choice that you can see on a wooden, plaster, or stone surface (such as a wall, a ceiling, or a floor) within range, and lasts for the duration. You choose the opening''s dimensions: up to 5 feet wide, 8 feet tall, and 20 feet deep. The passage creates no instability in a structure surrounding it.

When the opening disappears, any creatures or objects still in the passage created by the spell are safely ejected to an unoccupied space nearest to the surface on which you cast the spell.',NULL,'1 hour','1 action','Passwall',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),5,'30 feet','A pinch of sesame seeds',0,NULL);
	INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You tap into the nightmares of a creature you can see within range and create an illusory manifestation of its deepest fears, visible only to that creature. The target must make a Wisdom saving throw. On a failed save, the target becomes frightened for the duration. At the end of each of the target''s turns before the spell ends, the target must succeed on a Wisdom saving throw or take 4d10 psychic damage. On a successful save, the spell ends.','When you cast this spell using a spell slot of 5th level or higher, the damage increases by 1d10 for each slot level above 4th.','1 minute','1 action','Phantasmal Killer',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),4,'120 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A Large quasi-real, horselike creature appears on the ground in an unoccupied space of your choice within range. You decide the creature''s appearance, but it is equipped with a saddle, bit, and bridle. Any of the equipment created by the spell vanishes in a puff of smoke if it is carried more than 10 feet away from the steed.

For the duration, you or a creature you choose can ride the steed. The creature uses the statistics for a riding horse, except it has a speed of 100 feet and can travel 10 miles in an hour, or 13 miles at a fast pace. When the spell ends, the steed gradually fades, giving the rider 1 minute to dismount. The spell ends if you use an action to dismiss it or if the steed takes any damage.',NULL,'1 hour','1 minute','Phantom Steed',1,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),3,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You beseech an otherworldly entity for aid. The being must be known to you: a god, a primordial, a demon prince, or some other being of cosmic power. That entity sends a celestial, an elemental, or a fiend loyal to it to aid you, making the creature appear in an unoccupied space within range. If you know a specific creature''s name, you can speak that name when you cast this spell to request that creature, though you might get a different creature anyway (DM''s choice).

When the creature appears, it is under no compulsion to behave in any particular way. You can ask the creature to perform a service in exchange for payment, but it isn''t obliged to do so. The requested task could range from simple (fly us across the chasm, or help us fight a battle) to complex (spy on our enemies, or protect us during our foray into the dungeon). You must be able to communicate with the creature to bargain for its services.

Payment can take a variety of forms. A celestial might require a sizable donation of gold or magic items to an allied temple, while a fiend might demand a living sacrifice or a gift of treasure. Some creatures might exchange their service for a quest undertaken by you.

As a rule of thumb, a task that can be measured in minutes requires a payment worth 100 gp per minute. A task measured in hours requires 1,000 gp per hour. And a task measured in days (up to 10 days) requires 10,000 gp per day. The DM can adjust these payments based on the circumstances under which you cast the spell. If the task is aligned with the creature''s ethos, the payment might be halved or even waived. Nonhazardous tasks typically require only half the suggested payment, while especially dangerous tasks might require a greater gift. Creatures rarely accept tasks that seem suicidal.

After the creature completes the task, or when the agreed-upon duration of service expires, the creature returns to its home plane after reporting back to you, if appropriate to the task and if possible. If you are unable to agree on a price for the creature''s service, the creature immediately returns to its home plane.

A creature enlisted to join your group counts as a member of it, receiving a full share of experience points awarded.',NULL,'Instantaneous','10 minutes','Planar Ally',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),6,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'With this spell, you attempt to bind a celestial, an elemental, a fey, or a fiend to your service. The creature must be within range for the entire casting of the spell. (Typically, the creature is first summoned into the center of an inverted magic circle in order to keep it trapped while this spell is cast.) At the completion of the casting, the target must make a Charisma saving throw. On a failed save, it is bound to serve you for the duration. If the creature was summoned or created by another spell, that spell''s duration is extended to match the duration of this spell.

A bound creature must follow your instructions to the best of its ability. You might command the creature to accompany you on an adventure, to guard a location, or to deliver a message. The creature obeys the letter of your instructions, but if the creature is hostile to you, it strives to twist your words to achieve its own objectives. If the creature carries out your instructions completely before the spell ends, it travels to you to report this fact if you are on the same plane of existence. If you are on a different plane of existence, it returns to the place where you bound it and remains there until the spell ends.','When you cast this spell using a spell slot of a higher level, the duration increases to 10 days with a 6th-level slot, to 30 days with a 7th-level slot, to 180 days with an 8th-level slot, and to a year and a day with a 9th-level spell slot.','24 hours','1 hour','Planar Binding',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),5,'60 feet','A jewel worth at least 1,000 gp, which the spell consumes',1000,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You and up to eight willing creatures who link hands in a circle are transported to a different plane of existence. You can specify a target destination in general terms, such as the City of Brass on the Elemental Plane of Fire or the palace of Dispater on the second level of the Nine Hells, and you appear in or near that destination. If you are trying to reach the City of Brass, for example, you might arrive in its Street of Steel, before its Gate of Ashes, or looking at the city from across the Sea of Fire, at the DM''s discretion.

Alternatively, if you know the sigil sequence of a teleportation circle on another plane of existence, this spell can take you to that circle. If the teleportation circle is too small to hold all the creatures you transported, they appear in the closest unoccupied spaces next to the circle.

You can use this spell to banish an unwilling creature to another plane. Choose a creature within your reach and make a melee spell attack against it. On a hit, the creature must make a Charisma saving throw. If the creature fails this save, it is transported to a random location on the plane of existence you specify. A creature so transported must find its own way back to your current plane of existence.',NULL,'Instantaneous','1 action','Plane Shift',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),7,'Touch','A forked, metal rod worth at least 250 gp, attuned to a particular plane of existence',250,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'This spell channels vitality into plants within a specific area. There are two possible uses for the spell, granting either immediate or long-term benefits.

If you cast this spell using 1 action, choose a point within range. All normal plants in a 100-foot radius centered on that point become thick and overgrown. A creature moving through the area must spend 4 feet of movement for every 1 foot it moves.

You can exclude one or more areas of any size within the spell''s area from being affected.

If you cast this spell over 8 hours, you enrich the land. All plants in a half-mile radius centered on a point within range become enriched for 1 year. The plants yield twice the normal amount of food when harvested.',NULL,'Instantaneous','1 action','Plant Growth',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),3,'150 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You extend your hand toward a creature you can see within range and project a puff of noxious gas from your palm. The creature must succeed on a Constitution saving throw or take 1d12 poison damage.','This spell''s damage increases by 1d12 when you reach 5th level (2d12), 11th level (3d12), and 17th level (4d12).','Instantaneous','1 action','Poison Spray',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),0,'10 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'This spell transforms a creature that you can see within range into a new form. An unwilling creature must make a Wisdom saving throw to avoid the effect. The spell has no effect on a shapechanger or a creature with 0 hit points.

The transformation lasts for the duration, or until the target drops to 0 hit points or dies. The new form can be any beast whose challenge rating is equal to or less than the target''s (or the target''s level, if it doesn''t have a challenge rating). The target''s game statistics, including mental ability scores, are replaced by the statistics of the chosen beast. It retains its alignment and personality.

The target assumes the hit points of its new form. When it reverts to its normal form, the creature returns to the number of hit points it had before it transformed. If it reverts as a result of dropping to 0 hit points, any excess damage carries over to its normal form. As long as the excess damage doesn''t reduce the creature''s normal form to 0 hit points, it isn''t knocked unconscious.

The creature is limited in the actions it can perform by the nature of its new form, and it can''t speak, cast spells, or take any other action that requires hands or speech.

The target''s gear melds into the new form. The creature can''t activate, use, wield, or otherwise benefit from any of its equipment.',NULL,'1 hour','1 action','Polymorph',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),4,'60 feet','A caterpillar cocoon',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You utter a word of power that can compel one creature you can see within range to die instantly. If the creature you choose has 100 hit points or fewer, it dies. Otherwise, the spell has no effect.',NULL,'Instantaneous','1 action','Power Word Kill',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),9,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You speak a word of power that can overwhelm the mind of one creature you can see within range, leaving it dumbfounded. If the target has 150 hit points or fewer, it is stunned. Otherwise, the spell has no effect.

The stunned target must make a Constitution saving throw at the end of each of its turns. On a successful save, this stunning effect ends.',NULL,'Instantaneous','1 action','Power Word Stun',0,(SELECT rowid FROM school WHERE name LIKE 'Enchantment'),8,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Up to six creatures of your choice that you can see within range each regain hit points equal to 2d8 + your spellcasting ability modifier. This spell has no effect on undead or constructs.','When you cast this spell using a spell slot of 3rd level or higher, the healing increases by 1d8 for each slot level above 2nd.','Instantaneous','10 minutes','Prayer of Healing',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),2,'30 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'This spell is a minor magical trick that novice spellcasters use for practice. You create one of the following magical effects within range:

- You create an instantaneous, harmless sensory effect, such as a shower of sparks, a puff of wind, faint musical notes, or an odd odor.
- You instantaneously light or snuff out a candle, a torch, or a small campfire.
- You instantaneously clean or soil an object no larger than 1 cubic foot.
- You chill, warm, or flavor up to 1 cubic foot of nonliving material for 1 hour.
- You make a color, a small mark, or a symbol appear on an object or a surface for 1 hour.
- You create a nonmagical trinket or an illusory image that can fit in your hand and that lasts until the end of your next turn.

If you cast this spell multiple times, you can have up to three of its non-instantaneous effects active at a time, and you can dismiss such an effect as an action.',NULL,'1 hour','1 action','Prestidigitation',0,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),0,'10 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'Eight multicolored rays of light flash from your hand. Each ray is a different color and has a different power and purpose. Each creature in a 60-foot cone must make a Dexterity saving throw. For each target, roll a d8 to determine which color ray affects it.

1. Red. The target takes 10d6 fire damage on a failed save, or half as much damage on a successful one.

2. Orange. The target takes 10d6 acid damage on a failed save, or half as much damage on a successful one.

3. Yellow. The target takes 10d6 lightning damage on a failed save, or half as much damage on a successful one.

4. Green. The target takes 10d6 poison damage on a failed save, or half as much damage on a successful one.

5. Blue. The target takes 10d6 cold damage on a failed save, or half as much damage on a successful one.

6. Indigo. On a failed save, the target is restrained. It must then make a Constitution saving throw at the end of each of its turns. If it successfully saves three times, the spell ends. If it fails its save three times, it permanently turns to stone and is subjected to the petrified condition. The successes and failures don''t need to be consecutive; keep track of both until the target collects three of a kind.

7. Violet. On a failed save, the target is blinded. It must then make a Wisdom saving throw at the start of your next turn. A successful save ends the blindness. If it fails that save, the creature is transported to another plane of existence of the DM''s choosing and is no longer blinded. (Typically, a creature that is on a plane that isn''t its home plane is banished home, while other creatures are usually cast into the Astral or Ethereal planes.)

8. Special. The target is struck by two rays. Roll twice more, rerolling any 8.',NULL,'Instantaneous','1 action','Prismatic Spray',0,(SELECT rowid FROM school WHERE name LIKE 'Evocation'),7,'Self (60 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A shimmering, multicolored plane of light forms a vertical opaque wall—up to 90 feet long, 30 feet high, and 1 inch thick—centered on a point you can see within range. Alternatively, you can shape the wall into a sphere up to 30 feet in diameter centered on a point you choose within range. The wall remains in place for the duration. If you position the wall so that it passes through a space occupied by a creature, the spell fails, and your action and the spell slot are wasted.

The wall sheds bright light out to a range of 100 feet and dim light for an additional 100 feet. You and creatures you designate at the time you cast the spell can pass through and remain near the wall without harm. If another creature that can see the wall moves to within 20 feet of it or starts its turn there, the creature must succeed on a Constitution saving throw or become blinded for 1 minute.

The wall consists of seven layers, each with a different color. When a creature attempts to reach into or pass through the wall, it does so one layer at a time through all the wall''s layers. As it passes or reaches through each layer, the creature must make a Dexterity saving throw or be affected by that layer''s properties as described below.

The wall can be destroyed, also one layer at a time, in order from red to violet, by means specific to each layer. Once a layer is destroyed, it remains so for the duration of the spell. Antimagic field has no effect on the wall, and dispel magic can affect only the violet layer.

1. Red. The creature takes 10d6 fire damage on a failed save, or half as much damage on a successful one. While this layer is in place, nonmagical ranged attacks can''t pass through the wall. The layer can be destroyed by dealing at least 25 cold damage to it.

2. Orange. The creature takes 10d6 acid damage on a failed save, or half as much damage on a successful one. While this layer is in place, magical ranged attacks can''t pass through the wall. The layer is destroyed by a strong wind.

3. Yellow. The creature takes 10d6 lightning damage on a failed save, or half as much damage on a successful one. This layer can be destroyed by dealing at least 60 force damage to it.

4. Green. The creature takes 10d6 poison damage on a failed save, or half as much damage on a successful one. A passwall spell, or another spell of equal or greater level that can open a portal on a solid surface, destroys this layer.

5. Blue. The creature takes 10d6 cold damage on a failed save, or half as much damage on a successful one. This layer can be destroyed by dealing at least 25 fire damage to it.

6. Indigo. On a failed save, the creature is restrained. It must then make a Constitution saving throw at the end of each of its turns. If it successfully saves three times, the spell ends. If it fails its save three times, it permanently turns to stone and is subjected to the petrified condition. The successes and failures don''t need to be consecutive; keep track of both until the creature collects three of a kind.

While this layer is in place, spells can''t be cast through the wall. The layer is destroyed by bright light shed by a daylight spell or a similar spell of equal or higher level.

7. Violet. On a failed save, the creature is blinded. It must then make a Wisdom saving throw at the start of your next turn. A successful save ends the blindness. If it fails that save, the creature is transported to another plane of the DM''s choosing and is no longer blinded. (Typically, a creature that is on a plane that isn''t its home plane is banished home, while other creatures are usually cast into the Astral or Ethereal planes.) This layer is destroyed by a dispel magic spell or a similar spell of equal or higher level that can end spells and magical effects.',NULL,'10 minutes','1 action','Prismatic Wall',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),9,'60 feet',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'A flickering flame appears in your hand. The flame remains there for the duration and harms neither you nor your equipment. The flame sheds bright light in a 10-foot radius and dim light for an additional 10 feet. The spell ends if you dismiss it as an action or if you cast it again.

You can also attack with the flame, although doing so ends the spell. When you cast this spell, or as an action on a later turn, you can hurl the flame at a creature within 30 feet of you. Make a ranged spell attack. On a hit, the target takes 1d8 fire damage.','This spell''s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).','10 minutes','1 action','Produce Flame',0,(SELECT rowid FROM school WHERE name LIKE 'Conjuration'),0,'Self (30 feet)',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You create an illusion of an object, a creature, or some other visible phenomenon within range that activates when a specific condition occurs. The illusion is imperceptible until then. It must be no larger than a 30-foot cube, and you decide when you cast the spell how the illusion behaves and what sounds it makes. This scripted performance can last up to 5 minutes.

When the condition you specify occurs, the illusion springs into existence and performs in the manner you described. Once the illusion finishes performing, it disappears and remains dormant for 10 minutes. After this time, the illusion can be activated again.

The triggering condition can be as general or as detailed as you like, though it must be based on visual or audible conditions that occur within 30 feet of the area. For example, you could create an illusion of yourself to appear and warn off others who attempt to open a trapped door, or you could set the illusion to trigger only when a creature says the correct word or phrase.

Physical interaction with the image reveals it to be an illusion, because things can pass through it. A creature that uses its action to examine the image can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the creature can see through the image, and any noise it makes sounds hollow to the creature.',NULL,'Until Dispelled','1 action','Programmed Illusion',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),6,'120 feet (30 feet)','A bit of fleece and jade dust worth at least 25 gp',25,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'You create an illusory copy of yourself that lasts for the duration. The copy can appear at any location within range that you have seen before, regardless of intervening obstacles. The illusion looks and sounds like you but is intangible. If the illusion takes any damage, it disappears, and the spell ends.

You can use your action to move this illusion up to twice your speed, and make it gesture, speak, and behave in whatever way you choose. It mimics your mannerisms perfectly.

You can see through its eyes and hear through its ears as if you were in its space. On your turn as a bonus action, you can switch from using its senses to using your own, or back again. While you are using its senses, you are blinded and deafened in regard to your own surroundings.

Physical interaction with the image reveals it to be an illusion, because things can pass through it. A creature that uses its action to examine the image can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the creature can see through the image, and any noise it makes sounds hollow to the creature.',NULL,'1 day','1 action','Project Image',0,(SELECT rowid FROM school WHERE name LIKE 'Illusion'),7,'500 miles','A small replica of you made from materials worth at least 5 gp',5,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'For the duration, the willing creature you touch has resistance to one damage type of your choice: acid, cold, fire, lightning, or thunder.',NULL,'1 hour','1 action','Protection from Energy',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),3,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (1,'Until the spell ends, one willing creature you touch is protected against certain types of creatures: aberrations, celestials, elementals, fey, fiends, and undead.

The protection grants several benefits. Creatures of those types have disadvantage on attack rolls against the target. The target also can''t be charmed, frightened, or possessed by them. If the target is already charmed, frightened, or possessed by such a creature, the target has advantage on any new saving throw against the relevant effect.',NULL,'10 minutes','1 action','Protection from Evil and Good',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),1,'Touch','Holy water or powdered silver and iron, which the spell consumes',0,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'You touch a creature. If it is poisoned, you neutralize the poison. If more than one poison afflicts the target, you neutralize one poison that you know is present, or you neutralize one at random.

For the duration, the target has advantage on saving throws against being poisoned, and it has resistance to poison damage.',NULL,'1 hour','1 action','Protection from Poison',0,(SELECT rowid FROM school WHERE name LIKE 'Abjuration'),2,'Touch',NULL,NULL,NULL);
INSERT OR IGNORE INTO spell (concentration,description,higher_level_description,duration,casting_time,name,ritual,school,level,range,materials,materials_cost,reaction_condition) VALUES
    (0,'All nonmagical food and drink within a 5-foot-radius sphere centered on a point of your choice within range is purified and rendered free of poison and disease.',NULL,'Instantaneous','1 action','Purify Food and Drink',1,(SELECT rowid FROM school WHERE name LIKE 'Transmutation'),1,'10 feet (5 feet)',NULL,NULL,NULL);

COMMIT;

BEGIN TRANSACTION;

INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Harm'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heal'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Healing Word'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hellish Rebuke'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroes'' Feast'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroism'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroism'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hunter''s Mark'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Illusory Script'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Inflict Wounds'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Knock'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Armor'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Armor'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Missile'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Mouth'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Weapon'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Heal'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Heal'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Healing Word'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Healing Word'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Maze'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mind Blank'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mind Blank'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Minor Illusion'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirage Arcane'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirror Image'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mislead'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Misty Step'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Moonbeam'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM target WHERE type LIKE 'Corpse'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Otto''s Irresistible Dance'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Pass without Trace'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Pass without Trace'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Passwall'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantasmal Killer'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantom Steed'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Ally'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plant Growth'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Kill'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prayer of Healing'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prayer of Healing'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Produce Flame'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Programmed Illusion'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM target WHERE type LIKE 'Self'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM target WHERE type LIKE 'Creature'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM target WHERE type LIKE 'Object'));
INSERT OR IGNORE INTO spell_target (spell_id,target_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM target WHERE type LIKE 'Point in space'));

INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Harm'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hellish Rebuke'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Moonbeam'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Otto''s Irresistible Dance'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantasmal Killer'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM ability WHERE shortname LIKE 'CHA'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM ability WHERE shortname LIKE 'WIS'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM ability WHERE shortname LIKE 'CON'));
INSERT OR IGNORE INTO spell_ability (spell_id,ability_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM ability WHERE shortname LIKE 'DEX'));

INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hunter''s Mark'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Weapon'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hunter''s Mark'),(SELECT rowid FROM attack_type WHERE type LIKE 'Ranged Weapon'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Inflict Wounds'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Spell'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM attack_type WHERE type LIKE 'Melee Spell'));
INSERT OR IGNORE INTO spell_attack_type (spell_id,attack_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Produce Flame'),(SELECT rowid FROM attack_type WHERE type LIKE 'Ranged Spell'));

INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Harm'),(SELECT rowid FROM damage_type WHERE type LIKE 'Necrotic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heal'),(SELECT rowid FROM damage_type WHERE type LIKE 'Healing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Healing Word'),(SELECT rowid FROM damage_type WHERE type LIKE 'Healing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hellish Rebuke'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroes'' Feast'),(SELECT rowid FROM damage_type WHERE type LIKE 'Healing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM damage_type WHERE type LIKE 'Cold'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM damage_type WHERE type LIKE 'Bludgeoning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Inflict Wounds'),(SELECT rowid FROM damage_type WHERE type LIKE 'Necrotic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM damage_type WHERE type LIKE 'Piercing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM damage_type WHERE type LIKE 'Lightning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Missile'),(SELECT rowid FROM damage_type WHERE type LIKE 'Force'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM damage_type WHERE type LIKE 'Healing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Heal'),(SELECT rowid FROM damage_type WHERE type LIKE 'Healing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Healing Word'),(SELECT rowid FROM damage_type WHERE type LIKE 'Healing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM damage_type WHERE type LIKE 'Bludgeoning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM damage_type WHERE type LIKE 'Bludgeoning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Moonbeam'),(SELECT rowid FROM damage_type WHERE type LIKE 'Radiant'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM damage_type WHERE type LIKE 'Force'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantasmal Killer'),(SELECT rowid FROM damage_type WHERE type LIKE 'Psychic'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM damage_type WHERE type LIKE 'Poison'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prayer of Healing'),(SELECT rowid FROM damage_type WHERE type LIKE 'Healing'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM damage_type WHERE type LIKE 'Acid'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM damage_type WHERE type LIKE 'Lightning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM damage_type WHERE type LIKE 'Poison'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM damage_type WHERE type LIKE 'Cold'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM damage_type WHERE type LIKE 'Acid'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM damage_type WHERE type LIKE 'Lightning'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM damage_type WHERE type LIKE 'Poison'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM damage_type WHERE type LIKE 'Cold'));
INSERT OR IGNORE INTO spell_damage_type (spell_id,damage_type_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Produce Flame'),(SELECT rowid FROM damage_type WHERE type LIKE 'Fire'));

INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM condition WHERE name LIKE 'Frightened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM condition WHERE name LIKE 'Deafened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM condition WHERE name LIKE 'Stunned'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM condition WHERE name LIKE 'Paralyzed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM condition WHERE name LIKE 'Paralyzed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM condition WHERE name LIKE 'Restrained'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM condition WHERE name LIKE 'Unconscious'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM condition WHERE name LIKE 'Invisible'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM condition WHERE name LIKE 'Unconscious'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM condition WHERE name LIKE 'Prone'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mislead'),(SELECT rowid FROM condition WHERE name LIKE 'Invisible'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mislead'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mislead'),(SELECT rowid FROM condition WHERE name LIKE 'Deafened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM condition WHERE name LIKE 'Incapacitated'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Otto''s Irresistible Dance'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantasmal Killer'),(SELECT rowid FROM condition WHERE name LIKE 'Frightened'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM condition WHERE name LIKE 'Charmed'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM condition WHERE name LIKE 'Stunned'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM condition WHERE name LIKE 'Restrained'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM condition WHERE name LIKE 'Petrified'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM condition WHERE name LIKE 'Restrained'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM condition WHERE name LIKE 'Petrified'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM condition WHERE name LIKE 'Blinded'));
INSERT OR IGNORE INTO spell_condition (spell_id,condition_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM condition WHERE name LIKE 'Deafened'));

INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Harm'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heal'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Healing Word'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hellish Rebuke'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroes'' Feast'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroism'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hunter''s Mark'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Illusory Script'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Inflict Wounds'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Knock'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Armor'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Missile'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Mouth'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Weapon'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Heal'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Healing Word'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Maze'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mind Blank'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Minor Illusion'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirage Arcane'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirror Image'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mislead'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Misty Step'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Moonbeam'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Otto''s Irresistible Dance'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Pass without Trace'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Passwall'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantasmal Killer'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantom Steed'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Ally'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plant Growth'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Kill'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prayer of Healing'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Produce Flame'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Programmed Illusion'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));
INSERT OR IGNORE INTO spell_source (spell_id,source_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM source WHERE shortname LIKE 'SRD'));

INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Harm'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heal'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heal'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Healing Word'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Healing Word'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Healing Word'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hellish Rebuke'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroes'' Feast'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroes'' Feast'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroism'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroism'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hunter''s Mark'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Illusory Script'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Illusory Script'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Illusory Script'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Inflict Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Knock'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Knock'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Knock'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Armor'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Armor'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Missile'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Missile'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Mouth'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Mouth'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Mouth'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Weapon'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Weapon'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Weapon'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Heal'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Healing Word'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Maze'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mind Blank'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mind Blank'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Minor Illusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Minor Illusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Minor Illusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Minor Illusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirage Arcane'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirage Arcane'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirage Arcane'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirror Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirror Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirror Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mislead'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mislead'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Misty Step'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Misty Step'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Misty Step'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Moonbeam'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Otto''s Irresistible Dance'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Otto''s Irresistible Dance'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Pass without Trace'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Pass without Trace'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Passwall'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantasmal Killer'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantom Steed'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Ally'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plant Growth'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plant Growth'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plant Growth'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Kill'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Kill'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Kill'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Kill'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prayer of Healing'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Produce Flame'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Programmed Illusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Programmed Illusion'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Bard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM class_list WHERE class LIKE 'Sorcerer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM class_list WHERE class LIKE 'Warlock'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM class_list WHERE class LIKE 'Wizard'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM class_list WHERE class LIKE 'Ranger'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM class_list WHERE class LIKE 'Cleric'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM class_list WHERE class LIKE 'Druid'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM class_list WHERE class LIKE 'Paladin'));
INSERT OR IGNORE INTO spell_class_list (spell_id,class_list_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM class_list WHERE class LIKE 'Artificer'));

INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallow'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hallucinatory Terrain'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Harm'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Harm'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Haste'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heal'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heal'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Healing Word'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heat Metal'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hellish Rebuke'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hellish Rebuke'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroes'' Feast'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroes'' Feast'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroes'' Feast'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroism'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Heroism'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Monster'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hold Person'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Holy Aura'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hunter''s Mark'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Hypnotic Pattern'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Ice Storm'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Identify'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Illusory Script'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Illusory Script'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Imprisonment'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Incendiary Cloud'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Inflict Wounds'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Inflict Wounds'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Insect Plague'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Invisibility'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Jump'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Knock'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Legend Lore'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lesser Restoration'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Levitate'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Light'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Lightning Bolt'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Animals or Plants'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Creature'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Locate Object'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Longstrider'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Armor'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Armor'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Armor'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mage Hand'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Circle'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Jar'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Missile'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Missile'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Mouth'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Mouth'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Mouth'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Weapon'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Magic Weapon'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Major Image'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Cure Wounds'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Heal'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Heal'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Healing Word'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mass Suggestion'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Maze'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Maze'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meld into Stone'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mending'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Message'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Meteor Swarm'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mind Blank'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mind Blank'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Minor Illusion'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Minor Illusion'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirage Arcane'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirage Arcane'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirror Image'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mirror Image'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mislead'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Misty Step'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Modify Memory'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Moonbeam'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Moonbeam'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Moonbeam'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Mordenkainen''s Sword'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Move Earth'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Nondetection'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Otto''s Irresistible Dance'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Pass without Trace'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Pass without Trace'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Pass without Trace'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Passwall'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Passwall'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Passwall'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantasmal Killer'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantasmal Killer'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantom Steed'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Phantom Steed'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Ally'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Ally'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Planar Binding'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plane Shift'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plant Growth'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Plant Growth'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Poison Spray'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Polymorph'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Kill'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Power Word Stun'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prayer of Healing'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prestidigitation'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Spray'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Prismatic Wall'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Produce Flame'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Produce Flame'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Programmed Illusion'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Programmed Illusion'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Programmed Illusion'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Project Image'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Energy'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Evil and Good'),(SELECT rowid FROM component WHERE symbol LIKE 'M'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Protection from Poison'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM component WHERE symbol LIKE 'V'));
INSERT OR IGNORE INTO spell_component (spell_id,component_id) VALUES
    ((SELECT rowid FROM spell WHERE name LIKE 'Purify Food and Drink'),(SELECT rowid FROM component WHERE symbol LIKE 'S'));

COMMIT;
